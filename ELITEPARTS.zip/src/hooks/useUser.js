// hooks/useUser.js
import { useEffect, useState } from "react";
import axios from "axios";

export default function useUser() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => setUser(res.data.user))
      .catch(() => setUser(null));
  }, []);

  return user;
}
