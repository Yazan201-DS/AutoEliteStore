import { Routes, Route } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Login from '../pages/Login';
import Signup from '../pages/Signup';
import Registration from "../pages/Registration";
import AdminDashboard from '../pages/AdminDashboard';
import Brands from "../pages/Brands";
import CustomerDashboard from '../pages/CustomerDashboard';
import ManageProducts from '../pages/ManageProducts';
import ManageCategories from '../pages/ManageCategories';
import CustomerAccounts from '../pages/CustomerAccounts';
import Contact from "../pages/Contact";
import About from "../pages/About";
import Terms from "../pages/Terms";
import Privacy from "../pages/Privacy";
import Home from '../components/Home';
import ManufacturersPage from "../pages/ManufacturersPage";
import AdminRoute from "../components/AdminRoute";
import CustomerRoute from "../components/CustomerRoute";
import CatalogOverview from "../pages/CatalogOverview";
import Cart from '../pages/Cart';
import Profile from '../pages/Profile';
import ScrollToTopButton from '../components/ScrollToTopButton';
import OrderSuccess from "../pages/OrderSuccess";
import MyOrders from "../pages/MyOrders"; // ✅ NEW
import AllOrders from '../pages/AllOrders';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { ToastContainer } from "react-toastify";

import styles from './app.module.css';

if (import.meta.env.DEV) {
  localStorage.removeItem("user");
  window.dispatchEvent(new Event("role-change"));
}

function App() {
  return (
    <div className={styles.app}>
      <Navbar />

      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/auth" element={<Registration />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/order-success" element={<OrderSuccess />} />
          <Route path="/brands" element={<Brands />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/about" element={<About />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/catalog-overview" element={<CatalogOverview />} />
          <Route path="/manufacturers/:manufacturer" element={<ManufacturersPage />} />

          {/* ✅ Customer-only routes */}
          <Route
            path="/customer"
            element={
              <CustomerRoute>
                <CustomerDashboard />
              </CustomerRoute>
            }
          />
          <Route
            path="/my-orders"
            element={
              <CustomerRoute>
                <MyOrders />
              </CustomerRoute>
            }
          />

          {/* ✅ Admin-only routes */}
          <Route
            path="/admin"
            element={
              <AdminRoute>
                <AdminDashboard />
              </AdminRoute>
            }
          />
          <Route
            path="/admin/all-orders"
            element={
              <AdminRoute>
                <AllOrders />
              </AdminRoute>
            }
          />
          <Route
            path="/admin/products"
            element={
              <AdminRoute>
                <ManageProducts />
              </AdminRoute>
            }
          />
          <Route
            path="/admin/categories"
            element={
              <AdminRoute>
                <ManageCategories />
              </AdminRoute>
            }
          />
          <Route
            path="/admin/customers"
            element={
              <AdminRoute>
                <CustomerAccounts />
              </AdminRoute>
            }
          />
        </Routes>

        <ToastContainer position="top-center" autoClose={3000} />
        <ScrollToTopButton />
      </main>

      <Footer />
    </div>
  );
}

export default App;
