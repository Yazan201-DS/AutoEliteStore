import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../styles/AdminDashboard.module.css";
import profileStyles from "../styles/CustomerAccounts.module.css";

export default function CustomerAccounts() {
  const [customers, setCustomers] = useState([]);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [zoomImage, setZoomImage] = useState(null); // ✅ state for zoom modal
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => {
        if (res.data.user.role === "admin") {
          setIsAuthorized(true);
        } else {
          navigate("/login", { replace: true });
        }
      })
      .catch(() => navigate("/login", { replace: true }));
  }, [navigate]);

  useEffect(() => {
    if (!isAuthorized) return;

    axios.get("/api/customers", { withCredentials: true })
      .then(res => setCustomers(res.data))
      .catch(err => console.error("Failed to load customers", err));
  }, [isAuthorized]);

  if (!isAuthorized) return <div className={styles.dashboard}>Checking access...</div>;

  return (
    <div className={styles.mainContent}>
      <div className={profileStyles.container}>
        <h2 className={styles.h2cstomers}>Customer Accounts</h2>

        <div className={profileStyles.gridHeader}>
          <span className={profileStyles.cell}>Profile</span>
          <span className={profileStyles.cell}>Name</span>
          <span className={profileStyles.cell}>Email</span>
          <span className={profileStyles.cell}>Phone</span>
          <span className={profileStyles.cell}>Address</span>
        </div>

        {customers.map((c) => (
          <div key={c.user_id} className={profileStyles.row}>
            <img
              src={c.profile_picture ? `/images/profiles/${c.profile_picture}` : "/images/default-avatar.png"}
              alt={c.name}
              className={profileStyles.avatar}
              onClick={() => setZoomImage(c.profile_picture ? `/images/profiles/${c.profile_picture}` : "/images/default-avatar.png")}
              style={{ cursor: "pointer" }}
            />
            <span>{c.name}</span>
            <span>{c.email}</span>
            <span>{c.phone}</span>
            <span>{c.address}</span>
          </div>
        ))}

        {zoomImage && (
          <div className={profileStyles.modalOverlay} onClick={() => setZoomImage(null)}>
            <div className={profileStyles.modalContent}>
              <img src={zoomImage} alt="Zoomed" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
