import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import styles from "../styles/ManageCategories.module.css";
import Button from "../components/Button";
import EditCategoryModal from "../components/EditCategoryModal";

export default function ManageCategories() {
  const [categories, setCategories] = useState([]);
  const [name, setName] = useState("");
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [editingCategory, setEditingCategory] = useState(null);
  const [isAuthorized, setIsAuthorized] = useState(false);

  const navigate = useNavigate();

  // ✅ Admin role check
  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => {
        if (res.data.user.role === "admin") {
          setIsAuthorized(true);
        } else {
          navigate("/login", { replace: true });
        }
      })
      .catch(() => navigate("/login", { replace: true }));
  }, [navigate]);

  const fetchCategories = async () => {
    try {
      const res = await axios.get("/api/categories", { withCredentials: true });
      setCategories(res.data);
    } catch (err) {
      console.error("Failed to fetch categories:", err);
    }
  };

  useEffect(() => {
    if (isAuthorized) fetchCategories();
  }, [isAuthorized]);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setImage(file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result);
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };

  const handleAdd = async (e) => {
    e.preventDefault();

    if (!name || !image) {
      Swal.fire("Missing fields", "Please provide both name and image", "warning");
      return;
    }

    const formData = new FormData();
    formData.append("name", name);
    formData.append("image", image);

    try {
      await axios.post("/api/categories", formData, {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true
      });
      setName("");
      setImage(null);
      setImagePreview(null);
      fetchCategories();
      Swal.fire("Success", "Category added", "success");
    } catch (err) {
      console.error("Add failed:", err);
      Swal.fire("Error", "Failed to add category", "error");
    }
  };

  const handleDelete = async (id) => {
    const confirm = await Swal.fire({
      title: "Delete this category?",
      text: "This action cannot be undone.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it",
    });

    if (!confirm.isConfirmed) return;

    try {
      await axios.delete(`/api/categories/${id}`, { withCredentials: true });
      setCategories((prev) => prev.filter((cat) => cat.category_id !== id));
      Swal.fire("Deleted", "Category removed", "success");
    } catch (err) {
      console.error("Delete failed:", err);
      Swal.fire("Error", "Failed to delete", "error");
    }
  };

  if (!isAuthorized) return <div className={styles.container}>Checking access...</div>;

  return (
    <div className={styles.container}>
      <h2>Manage Categories</h2>

      <form onSubmit={handleAdd} className={styles.form}>
        <input
          type="text"
          placeholder="Category Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input type="file" accept="image/*" onChange={handleImageChange} required />
        {imagePreview && (
          <img
            src={imagePreview}
            alt="Preview"
            style={{ width: "200px", height: "auto", borderRadius: "8px", marginBottom: "1rem" }}
          />
        )}
        <Button text="Add Category" type="submit" />
      </form>

      <div className={styles.grid}>
        {categories.map((cat) => (
          <div key={cat.category_id} className={styles.card}>
            <img
              src={`http://localhost:5000/images/categories/${cat.image}`}
              alt={cat.name}
              className={styles.image}
            />
            <h3>{cat.name}</h3>
            <Button text="Edit" func={() => setEditingCategory(cat)} />
            <Button text="Delete" className={styles.delete} func={() => handleDelete(cat.category_id)} />
          </div>
        ))}
      </div>

      {editingCategory && (
        <EditCategoryModal
          category={editingCategory}
          onClose={() => setEditingCategory(null)}
          onUpdate={fetchCategories}
        />
      )}
    </div>
  );
}
