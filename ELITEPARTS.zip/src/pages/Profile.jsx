import { useEffect, useState } from "react";
import axios from "axios";
import styles from "../styles/Profile.module.css";

export default function Profile() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => setUser(res.data.user))
      .catch(() => setUser(null));
  }, []);

  if (!user) return <div className={styles.container}>Loading profile...</div>;

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>My Profile</h2>

      <div className={styles.profileCard}>
        <div className={styles.imageWrapper}>
          <img
            src={
              user.profile_picture
                ? `/images/profiles/${user.profile_picture}`
                : "/images/default-avatar.png"
            }
            alt="Profile"
            onError={(e) => (e.target.src = "/images/default-avatar.png")}
            className={styles.avatar}
          />
        </div>

        <div className={styles.infoBox}>
          <p><strong>Name:</strong> {user.username}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <p><strong>Phone:</strong> {user.phone}</p>
          <p><strong>Address:</strong> {user.address}</p>
          <p><strong>Role:</strong> {user.role}</p>
        </div>
      </div>
    </div>
  );
}
