// Brands.jsx
import ManufactureBar from "../components/ManufactureBar";
import ManufacturersPage from "./ManufacturersPage"; // this is your existing dynamic page
import styles from "../styles/Brands.module.css";

export default function Brands() {
  return (
    <div className={styles.brandsPage}>
      <h1 className={styles.heading}>🚘 Browse by Brand</h1>
      <ManufactureBar />
      <ManufacturersPage disableAdminActions />
    </div>
  );
}
