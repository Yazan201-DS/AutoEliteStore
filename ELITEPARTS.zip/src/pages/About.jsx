// About.jsx
import styles from "../styles/AboutPage.module.css";

export default function About() {
  return (
    <div className={styles.aboutPage}>
      <div className={styles.aboutBox}>
        <h2>ℹ️ About Auto Elite</h2>

        <section>
          <h2>Who We Are</h2>
          <p>
            Auto Elite Stock is a premium supplier of genuine and aftermarket auto parts for luxury vehicles — especially Mercedes-Benz. Built by mechanics for mechanics, we focus on precision, compatibility, and reliability.
          </p>
        </section>

        <section>
          <h2>Our Mission</h2>
          <p>
            To make sourcing auto parts as easy as possible. We offer a seamless digital experience, quick shipping, and top-notch customer care — from browsing to delivery.
          </p>
        </section>

        <section>
          <h2>Our Values</h2>
          <ul>
            <li><strong>Expertise:</strong> Hands-on mechanical knowledge.</li>
            <li><strong>Delivery:</strong> Fast, reliable shipping every time.</li>
            <li><strong>Trust:</strong> Clear pricing and secure checkout.</li>
            <li><strong>Support:</strong> Real-time help when you need it.</li>
          </ul>
        </section>

        <section>
          <h2>Why Choose Us?</h2>
          <p>
            Unlike marketplaces, our catalog is filtered by brand, category, model, and year — so you always find the right fit. No guesswork. Just results.
          </p>
        </section>

        <section>
          <h2>Thank You</h2>
          <p>
            Whether you're fixing one car or managing a fleet, Auto Elite is your trusted spare parts partner.
          </p>
        </section>
      </div>
    </div>
  );
}
