import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import styles from "../styles/signUpIn.module.css";
import Button from "../components/Button";
import { FaEye, FaEyeSlash } from "react-icons/fa";

export default function Registration() {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    phone: "",
    address: "",
  });
  const [confirmPassword, setConfirmPassword] = useState("");
  const [profilePicture, setProfilePicture] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("/api/me", { withCredentials: true })
      .then((res) => {
        const user = res.data.user;
        navigate(user.role === "admin" ? "/admin" : "/customer", {
          replace: true,
        });
      })
      .catch(() => {});
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value.trimStart() }));
  };

  const validateForm = () => {
    const nameRegex = /^[A-Za-z]{2,}$/;
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{3,8}$/;

    if (!isLoginMode) {
      if (!nameRegex.test(form.username)) {
        setError("Username must contain only letters and be at least 2 characters long.");
        return false;
      }

      if (!passwordRegex.test(form.password)) {
        setError("Password must be 3–8 characters, alphanumeric, with at least one letter and one digit.");
        return false;
      }

      if (form.password !== confirmPassword) {
        setError("Passwords do not match.");
        return false;
      }

      if (!profilePicture) {
        setError("Please upload a profile picture.");
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (!validateForm()) {
      setLoading(false);
      return;
    }

    try {
      await new Promise((res) => setTimeout(res, 2000)); // simulate delay

      if (isLoginMode) {
        const res = await axios.post(
          "/api/login",
          {
            email: form.email,
            password: form.password,
          },
          { withCredentials: true }
        );

        localStorage.setItem("lastEmail", form.email);
        const user = res.data.user;

        Swal.fire({
          icon: "success",
          title: "Logged in!",
          text: "You have successfully logged in.",
          timer: 2000,
          showConfirmButton: false,
        });

        setTimeout(() => {
          navigate(user.role === "admin" ? "/admin" : "/customer", {
            replace: true,
          });
        }, 2000);
      } else {
        const formData = new FormData();
        for (const key in form) {
          formData.append(key, form[key]);
        }
        formData.append("profile_picture", profilePicture);

        const res = await axios.post("/api/signup", formData, {
          headers: { "Content-Type": "multipart/form-data" },
          withCredentials: true,
        });

        const user = res.data.user;

        Swal.fire({
          icon: "success",
          title: "Signed up!",
          text: "Your account has been created successfully.",
          timer: 2000,
          showConfirmButton: false,
        });

        setTimeout(() => {
          navigate(user.role === "admin" ? "/admin" : "/customer");
        }, 2000);
      }
    } catch (err) {
      console.error(err);
      Swal.fire({
        icon: "error",
        title: isLoginMode ? "Login failed" : "Signup failed",
        text: err.response?.data?.message || "Something went wrong. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleMode = () => {
    const newMode = !isLoginMode;
    setIsLoginMode(newMode);
    setError("");
    setShowPassword(false);

    setForm((prev) => ({
      ...prev,
      email: newMode ? localStorage.getItem("lastEmail") || "" : "",
      password: "",
    }));
    setConfirmPassword("");
    setProfilePicture(null);
  };

  return (
    <div className={styles.authContainer}>
      <div className={styles.formBox}>
        <h2 className={styles.title}>
          {isLoginMode ? "Login" : "Sign Up"}
        </h2>
        <form onSubmit={handleSubmit} className={styles.form}>
          {!isLoginMode && (
            <>
              <input
                type="text"
                name="username"
                placeholder="Username"
                value={form.username}
                onChange={handleChange}
                required
                className={styles.input}
              />
              <input
                type="text"
                name="phone"
                placeholder="Phone"
                value={form.phone}
                onChange={handleChange}
                required
                className={styles.input}
              />
              <input
                type="text"
                name="address"
                placeholder="Address"
                value={form.address}
                onChange={handleChange}
                required
                className={styles.input}
              />
            </>
          )}

          <input
            type="email"
            name="email"
            placeholder="Email"
            value={form.email}
            onChange={handleChange}
            required
            className={styles.input}
          />

          <div className={styles.passwordWrapper}>
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              required
              className={styles.input}
            />
            <Button
              type="button"
              func={() => setShowPassword((prev) => !prev)}
              className={styles.passwordToggleBtn}
              text={showPassword ? <FaEyeSlash /> : <FaEye />}
            />
          </div>

          {!isLoginMode && (
            <>
              <input
                type="password"
                placeholder="Confirm Password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className={styles.input}
              />
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setProfilePicture(e.target.files[0])}
                required
                className={styles.input}
              />
            </>
          )}

          <Button
            type="submit"
            text={loading ? "Loading..." : isLoginMode ? "Login" : "Sign Up"}
            className={styles.button}
            disabled={loading}
          />
        </form>

        {loading && <div className={styles.spinner}></div>}
        {error && <p className={styles.error}>{error}</p>}

        <p className={styles.footerText}>
          {isLoginMode ? "Don’t have an account?" : "Already have an account?"}
          <Button
            type="button"
            text={isLoginMode ? "Sign Up" : "Login"}
            func={toggleMode}
            className={styles.toggleBtn}
          />
        </p>

        <div className={styles.reviewBox}>
          <p>Email: yazan644@gmail.com<br />Password: yazan1234<br />Role: admin</p>
          <p>Email: saed999@gmail.com<br />Password: saed1234<br />Role: admin</p>
          <p>Email: ameer@gmail.com<br />Password: ameer123<br />Role: customer</p>
        </div>
      </div>
    </div>
  );
}
