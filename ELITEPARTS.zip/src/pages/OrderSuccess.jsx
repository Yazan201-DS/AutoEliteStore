import { Link } from "react-router-dom";
import styles from "../styles/OrderSuccess.module.css";

export default function OrderSuccess() {
  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <h1 className={styles.title}>🎉 Thank You for Your Order!</h1>
        <p className={styles.message}>
          Your purchase has been successfully completed and your order is being
          processed.
        </p>
        <p className={styles.subtext}>You will receive a confirmation email shortly.</p>
        <Link to="/catalog-overview" className={styles.button}>
          Continue Shopping
        </Link>
      </div>
    </div>
  );
}
