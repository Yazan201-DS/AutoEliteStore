import { useEffect, useState } from "react";
import axios from "axios";
import styles from "../styles/AllOrders.module.css";

export default function AllOrders() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    axios
      .get("/api/orders/all", { withCredentials: true })
      .then((res) => setOrders(res.data))
      .catch((err) => console.error("❌ Failed to fetch all orders:", err));
  }, []);

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>📦 All Customer Orders</h2>

      {orders.length === 0 ? (
        <p className={styles.empty}>No orders found.</p>
      ) : (
        orders.map((order) => (
          <div key={order.order_id} className={styles.orderCard}>
            <div className={styles.userHeader}>
              <img
                src={`/images/profiles/${order.profile_picture || "default.jpg"}`}
                alt={order.name}
                className={styles.profilePic}
              />
              <h3>{order.name}</h3>
            </div>

            <p><strong>Order ID:</strong> {order.order_id}</p>
            <p><strong>Date:</strong> {new Date(order.order_date).toLocaleString()}</p>
            <p><strong>Status:</strong> {order.status}</p>
            <p><strong>Total:</strong> ${order.total_price}</p>

            <div className={styles.products}>
              {order.items.map((item, index) => (
                <div key={index} className={styles.productItem}>
                  <img src={`/images/products/${item.image}`} alt={item.name} />
                  <div>
                    <p><strong>{item.name}</strong></p>
                    <p>Price: ${item.price}</p>
                    <p>Quantity: {item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}
