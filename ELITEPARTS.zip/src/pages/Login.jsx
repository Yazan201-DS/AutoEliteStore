import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import styles from "../styles/signUpIn.module.css";
import Button from "../components/Button";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // ✅ Auto-redirect if session already active
  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => {
        const user = res.data.user;
        navigate(user.role === "admin" ? "/admin" : "/customer", { replace: true });

        window.history.pushState(null, "", window.location.href);
        window.onpopstate = () => {
          navigate(user.role === "admin" ? "/admin" : "/customer", { replace: true });
        };
      })
      .catch(() => {
        // no session, stay on login
      });

    const savedEmail = localStorage.getItem("lastEmail");
    if (savedEmail) setEmail(savedEmail);
  }, [navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const res = await axios.post("/api/login", { email, password }, { withCredentials: true });

      const user = res.data.user;
      localStorage.setItem("lastEmail", email);
      navigate(user.role === "admin" ? "/admin" : "/customer", { replace: true });
    } catch (err) {
      setError("Invalid credentials");
    }
  };

  return (
    <div className={styles.authContainer}>
      <div className={styles.formBox}>
        <h2 className={styles.title}>
          <span className={styles.icon}></span> Login
        </h2>
        <form onSubmit={handleLogin} autoComplete="on" className={styles.form}>
          <input
            type="email"
            name="email"
            autoComplete="email"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className={styles.input}
          />
          <input
            type="password"
            name="password"
            autoComplete="current-password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className={styles.input}
          />
          <Button type="submit" text="LOGIN" className={styles.button} />
        </form>

        {error && <p className={styles.error}>{error}</p>}

        <p className={styles.footerText}>
          Don’t have an account? <Link to="/signup">Create an account</Link>
        </p>
      </div>
    </div>
  );
}
