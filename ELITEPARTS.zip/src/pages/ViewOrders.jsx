export default function ViewOrders() {
    return (
      <div style={{ padding: "2rem" }}>
        <h2>View Orders</h2>
        <p>Track and manage customer orders here.</p>
      </div>
    );
  }
  