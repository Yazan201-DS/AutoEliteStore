import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import styles from "../styles/BrandPages.module.css";
import axios from "axios";
import Swal from "sweetalert2";
import Button from "../components/Button";
import AdminEditProduct from "../components/AdminEditProduct";
import useUser from "../hooks/useUser";

export default function ManufacturersPage({ disableAdminActions = false }) {
  const { manufacturer } = useParams();
  const [data, setData] = useState(null);
  const [products, setProducts] = useState([]);
  const [editingProduct, setEditingProduct] = useState(null);
  const [zoomedImage, setZoomedImage] = useState(null);

  const user = useUser();
  const role = user?.role;

  const displayNameMap = {
    mercedesbenz: "Mercedes-Benz",
    bmw: "BMW",
    skoda: "Skoda",
    seat: "Seat",
  };

  useEffect(() => {
    axios.get(`/api/manufacturers/name/${manufacturer}`)
      .then(res => setData(res.data))
      .catch(err => console.error("Error loading manufacturer:", err));

    axios.get(`/api/manufacturers/products/${manufacturer}`)
      .then(res => {
        // ✅ Add default quantity field
        const productsWithQty = res.data.map(p => ({ ...p, quantity: 1 }));
        setProducts(productsWithQty);
      })
      .catch(err => console.error("Error loading products:", err));
  }, [manufacturer]);

  const handleEdit = (product) => setEditingProduct(product);

  const handleSaveEdit = async (updated) => {
    try {
      await axios.put(`/api/products/${updated.product_id}`, updated);
      setProducts(prev =>
        prev.map(p => p.product_id === updated.product_id ? { ...p, ...updated } : p)
      );
      setEditingProduct(null);
    } catch (err) {
      console.error("Failed to update:", err);
    }
  };

  const handleDelete = async (productId) => {
    const confirm = await Swal.fire({
      title: "Are you sure?",
      text: "This product will be permanently deleted.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
    });

    if (confirm.isConfirmed) {
      try {
        await axios.delete(`/api/products/${productId}`);
        setProducts(prev => prev.filter(p => p.product_id !== productId));
        Swal.fire("Deleted!", "Product has been deleted.", "success");
      } catch (err) {
        console.error("Delete failed:", err);
        Swal.fire("Error", "Failed to delete product.", "error");
      }
    }
  };

  const handleQuantityChange = (productId, qty) => {
    const quantity = Math.max(1, Number(qty));
    setProducts(prev =>
      prev.map(p =>
        p.product_id === productId ? { ...p, quantity } : p
      )
    );
  };

  const handleAddToCart = async (product) => {
    const quantity = product.quantity || 1;
    try {
      await axios.post("/api/cart", {
        product_id: product.product_id,
        quantity
      }, { withCredentials: true });

      Swal.fire("Success", "Added to cart!", "success");
    } catch (err) {
      console.error("Add to cart failed", err);
      Swal.fire("Error", "Could not add item to cart.", "error");
    }
  };

  const handleImageClick = (src) => setZoomedImage(src);
  const closeZoom = () => setZoomedImage(null);

  if (!data) return <p></p>;

  return (
    <div className={styles.brandPage}>
      <div className={styles.headerRow}>
        <img
          src={`/images/manufacturers/${data.image}`}
          alt={data.name}
          className={styles.brandLogo}
        />
        <h1 className={styles.h1br}>
          {displayNameMap[data.name] || data.name}
        </h1>
      </div>

      <h2 className={styles.subheading}>Available Products</h2>

      <div className={styles.tableWrapper}>
        <div className={styles.tableHeader}>
          <span>Image</span>
          <span>Name</span>
          <span>Description</span>
          <span>Model</span>
          <span>Year</span>
          <span>Price</span>
          <span>Category</span>
          <span>Subcategory</span>
          <span>Supplier</span>
          <span>In Stock</span>
          <span>Actions</span>
        </div>

        {products.map((product) => (
          <div className={styles.tableRow} key={product.product_id}>
            <span className={styles.imageZoomWrapper}>
              <img
                src={`/images/products/${product.image}`}
                alt={product.name}
                className={styles.tableImage}
                onClick={() => handleImageClick(`/images/products/${product.image}`)}
              />
            </span>
            <span>{product.name}</span>
            <span className={styles.descriptionCell}>{product.description}</span>
            <span>{product.model_class}</span>
            <span>{product.model_year}</span>
            <span>${parseFloat(product.price).toFixed(2)}</span>
            <span>{product.category_name || "-"}</span>
            <span>{product.subcategory_name || "-"}</span>
            <span>{product.supplier_name}</span>
            <span>{product.stock_quantity}</span>

            <span className={styles.actionCell}>
              {role === "admin" && !disableAdminActions && (
                <>
                  <Button
                    text="Edit"
                    className={styles.linkButton}
                    func={() => handleEdit(product)}
                  />
                  <Button
                    text="Delete"
                    className={styles.linkButton}
                    func={() => handleDelete(product.product_id)}
                  />
                </>
              )}

              {role === "customer" && (
                <>
                  <input
                    type="number"
                    min="1"
                    max={product.stock_quantity}
                    value={product.quantity}
                    onChange={(e) =>
                      handleQuantityChange(product.product_id, e.target.value)
                    }
                    className={styles.qtyInput}
                  />
                  <Button
                    text="Add to Cart"
                    className={styles.linkButton}
                    func={() => handleAddToCart(product)}
                  />
                </>
              )}
            </span>
          </div>
        ))}
      </div>

      {editingProduct && (
        <AdminEditProduct
          product={editingProduct}
          onClose={() => setEditingProduct(null)}
          onSave={handleSaveEdit}
        />
      )}

      {zoomedImage && (
        <div className={styles.zoomOverlay} onClick={closeZoom}>
          <img src={zoomedImage} alt="Zoomed" className={styles.zoomedImage} />
        </div>
      )}
    </div>
  );
}
