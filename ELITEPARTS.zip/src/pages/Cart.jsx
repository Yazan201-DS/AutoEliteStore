import { useEffect, useState } from "react";
import axios from "axios";
import styles from "../styles/CartFlex.module.css";
import Button from "../components/Button";
import PayPalCheckout from "../components/PayPalCheckout";
import useUser from "../hooks/useUser";

export default function Cart() {
  const [cartItems, setCartItems] = useState([]);
  const [total, setTotal] = useState(0);
  const user = useUser();

  const fetchCart = async () => {
    try {
      const res = await axios.get("/api/cart", { withCredentials: true });
      setCartItems(res.data);
    } catch (err) {
      console.error("Failed to load cart:", err);
    }
  };

  useEffect(() => {
    fetchCart();
  }, []);

  useEffect(() => {
    const totalPrice = cartItems.reduce(
      (sum, item) => sum + Number(item.price) * item.quantity,
      0
    );
    setTotal(totalPrice);
  }, [cartItems]);

  const handleRemove = async (product_id) => {
    try {
      await axios.delete(`/api/cart/${product_id}`, { withCredentials: true });
      setCartItems((prev) => prev.filter((item) => item.product_id !== product_id));
    } catch (err) {
      console.error("Failed to remove item:", err);
    }
  };

  const handleQuantityChange = async (product_id, newQty) => {
    if (newQty < 1) return;
    try {
      await axios.put(
        "/api/cart",
        { product_id, quantity: newQty },
        { withCredentials: true }
      );
      setCartItems((prev) =>
        prev.map((item) =>
          item.product_id === product_id ? { ...item, quantity: newQty } : item
        )
      );
    } catch (err) {
      console.error("Failed to update quantity:", err);
    }
  };

  return (
    <div className={styles.container}>
      <h2 className={styles.heading}>Your Cart</h2>

      <div className={styles.headerRow}>
        <span>Image</span>
        <span>Name</span>
        <span>Price</span>
        <span>Qty</span>
        <span>Total</span>
        <span>Action</span>
      </div>

      {cartItems.length === 0 ? (
        <p className={styles.emptyMessage}>Your cart is empty.</p>
      ) : (
        <>
          {cartItems.map((item) => (
            <div key={item.product_id} className={styles.itemRow}>
              <img
                src={`/images/products/${item.image}`}
                alt={item.name}
                className={styles.image}
              />
              <span>{item.name}</span>
              <span>${Number(item.price).toFixed(2)}</span>
              <input
                type="number"
                min="1"
                value={item.quantity}
                onChange={(e) =>
                  handleQuantityChange(item.product_id, parseInt(e.target.value))
                }
                className={styles.qtyInput}
              />
              <span>${(Number(item.price) * item.quantity).toFixed(2)}</span>
              <Button
                text="Remove"
                func={() => handleRemove(item.product_id)}
                className={styles.removeButton}
              />
            </div>
          ))}

          <div className={styles.totalBox}>
            <h3>Total: ${total.toFixed(2)}</h3>
            {user ? (
              <PayPalCheckout cartItems={cartItems} total={total} user={user} />
            ) : (
              <p>Please login to complete your order.</p>
            )}
          </div>
        </>
      )}
    </div>
  );
}
