import { useEffect, useState } from "react";
import axios from "axios";
import styles from "../styles/MyOrders.module.css";

export default function MyOrders() {
  const [orders, setOrders] = useState([]);
  const [zoomImage, setZoomImage] = useState(null);

  useEffect(() => {
    axios
      .get("/api/orders", { withCredentials: true })
      .then((res) => setOrders(res.data))
      .catch((err) => {
        console.error("Failed to load orders:", err);
      });
  }, []);

  // ESC key closes image modal
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.key === "Escape") setZoomImage(null);
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, []);

  if (!orders.length) {
    return <p className={styles.empty}>You haven’t placed any orders yet.</p>;
  }

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>My Orders</h2>

      {orders.map((order) => (
        <div key={order.order_id} className={styles.orderCard}>
          <div className={styles.header}>
            <span><strong>Order #{order.order_id}</strong></span>
            <span>{new Date(order.order_date).toLocaleString()}</span>
          </div>

          <div className={styles.items}>
            <h4>Items:</h4>
            <ul className={styles.itemList}>
              {order.items.map((item, idx) => (
                <li key={idx} className={styles.item}>
                  <div
                    className={styles.imageWrapper}
                    onClick={() =>
                      setZoomImage({
                        src: `/images/products/${item.image}`,
                        alt: item.name,
                      })
                    }
                  >
                    <img
                      src={`/images/products/${item.image}`}
                      alt={item.name}
                      className={styles.itemImage}
                    />
                  </div>
                  <div className={styles.itemInfo}>
                    <div>{item.name} × {item.quantity}</div>
                    <div className={styles.price}>
                      ${Number(item.price).toFixed(2)} each
                    </div>
                    <div className={styles.subtotal}>
                      Subtotal: ${(Number(item.price) * item.quantity).toFixed(2)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className={styles.footer}>
            <strong>Total:</strong> ${Number(order.total_price).toFixed(2)}
            <span className={styles.status}>{order.status}</span>
          </div>
        </div>
      ))}

      {/* ✅ Zoomed image modal */}
      {zoomImage && (
        <div className={styles.modalOverlay} onClick={() => setZoomImage(null)}>
          <img
            src={zoomImage.src}
            alt={zoomImage.alt}
            className={styles.modalImage}
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
