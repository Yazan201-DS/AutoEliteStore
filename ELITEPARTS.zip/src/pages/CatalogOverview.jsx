import { useEffect, useState } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import styles from "../styles/CatalogOverview.module.css";
import ImageModal from "../components/ImageModal";
import Button from "../components/Button";
import EditProductModal from "../components/EditProductModal";
import CatalogSearch from "../components/CatalogSearch";

export default function CatalogOverview() {
  const [data, setData] = useState([]);
  const [previewImage, setPreviewImage] = useState(null);
  const [editingProduct, setEditingProduct] = useState(null);
  const [quantities, setQuantities] = useState({});
  const [role, setRole] = useState("guest");

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSubcategory, setSelectedSubcategory] = useState("");
  const [selectedModelYear, setSelectedModelYear] = useState("");
  const [selectedModelClass, setSelectedModelClass] = useState("");

  const fetchCatalog = async () => {
    try {
      const res = await axios.get("/api/products/grouped-by-brand-category", {
        withCredentials: true,
      });
      setData(res.data);
    } catch (err) {
      console.error("Error fetching catalog data", err);
    }
  };

  useEffect(() => {
    fetchCatalog();

    axios
      .get("/api/me", { withCredentials: true })
      .then((res) => {
        setRole(res.data.user.role);
      })
      .catch(() => {
        setRole("guest");
      });
  }, []);

  const handleQtyChange = (productId, value) => {
    const intValue = parseInt(value);
    setQuantities((prev) => ({
      ...prev,
      [productId]: isNaN(intValue) || intValue < 1 ? 1 : intValue,
    }));
  };

  const handleAddToCart = async (product) => {
    const qty = quantities[product.product_id] || 1;

    if (qty < 1 || isNaN(qty)) {
      Swal.fire("Invalid Quantity", "Please enter a number greater than 0", "warning");
      return;
    }

    try {
      await axios.post(
        "/api/cart",
        {
          product_id: product.product_id,
          quantity: qty,
        },
        { withCredentials: true }
      );

      Swal.fire("Success", `"${product.name}" added to cart`, "success");
    } catch (err) {
      console.error("Add to cart error:", err);
      Swal.fire("Error", "Failed to add to cart", "error");
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
  };

  const handleDelete = async (product) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: `Delete "${product.name}"?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#e60023",
    });

    if (result.isConfirmed) {
      try {
        await axios.delete(`/api/products/${product.product_id}`, {
          withCredentials: true,
        });
        Swal.fire("Deleted!", `"${product.name}" has been removed.`, "success");
        await fetchCatalog();
      } catch (err) {
        console.error("Delete error:", err);
        Swal.fire("Error", "Failed to delete product", "error");
      }
    }
  };

  const handleClearFilters = () => {
    setSearchTerm("");
    setSelectedBrand("");
    setSelectedCategory("");
    setSelectedSubcategory("");
    setSelectedModelYear("");
    setSelectedModelClass("");
  };

  return (
    <div className={styles.page}>
      <h1 className={styles.heading}>Explore Our Catalog</h1>

      <CatalogSearch
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        selectedBrand={selectedBrand}
        setSelectedBrand={setSelectedBrand}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        selectedSubcategory={selectedSubcategory}
        setSelectedSubcategory={setSelectedSubcategory}
        selectedModelYear={selectedModelYear}
        setSelectedModelYear={setSelectedModelYear}
        selectedModelClass={selectedModelClass}
        setSelectedModelClass={setSelectedModelClass}
        data={data}
        onClearFilters={handleClearFilters}
      />

      {data
        .filter((brand) => !selectedBrand || brand.brandName === selectedBrand)
        .map((brand) => (
          <div key={brand.brandName} className={styles.brandBlock}>
            <h2 className={styles.brandTitle}>{brand.brandName}</h2>

            {brand.categories
              .filter((cat) => !selectedCategory || cat.categoryName === selectedCategory)
              .map((cat) => {
                const filteredProducts = cat.products.filter((p) => {
                  const matchesSearch =
                    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    p.description.toLowerCase().includes(searchTerm.toLowerCase());

                  const matchesSubcategory =
                    !selectedSubcategory || p.subcategory_name === selectedSubcategory;
                  const matchesModelYear =
                    !selectedModelYear || p.model_year?.toString() === selectedModelYear;
                  const matchesModelClass =
                    !selectedModelClass || p.model_class === selectedModelClass;

                  return matchesSearch && matchesSubcategory && matchesModelYear && matchesModelClass;
                });

                if (filteredProducts.length === 0) return null;

                return (
                  <div key={cat.categoryName} className={styles.categoryBlock}>
                    <h3 className={styles.categoryTitle}>{cat.categoryName}</h3>
                    <div className={styles.productsGrid}>
                      {filteredProducts.map((product) => (
                        <div key={product.product_id} className={styles.productCard}>
                          <img
                            src={`/images/products/${product.image}`}
                            alt={product.name}
                            className={styles.productImage}
                            onClick={() =>
                              setPreviewImage(`/images/products/${product.image}`)
                            }
                          />
                          <h4 className={styles.productName}>{product.name}</h4>
                          <p className={styles.productPrice}>${product.price}</p>
                          <p className={styles.productInfo}>
                            <strong>Model Year:</strong> {product.model_year || "N/A"}
                          </p>
                          <p className={styles.productInfo}>
                            <strong>Model Class:</strong> {product.model_class || "N/A"}
                          </p>
                          <p className={styles.productDescription}>
                            {product.description || "No description provided."}
                          </p>

                          {role === "admin" && (
                            <div className={styles.adminActions}>
                              <Button text="Edit" func={() => handleEdit(product)} />
                              <Button text="Delete" func={() => handleDelete(product)} />
                            </div>
                          )}

                          {role === "customer" && (
                            <div className={styles.customerActions}>
                              <input
                                type="number"
                                min="1"
                                defaultValue="1"
                                className={styles.qtyInput}
                                onChange={(e) =>
                                  handleQtyChange(product.product_id, e.target.value)
                                }
                              />
                              <Button
                                text="Add to Cart"
                                func={() => handleAddToCart(product)}
                              />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
          </div>
        ))}

      <ImageModal imageSrc={previewImage} onClose={() => setPreviewImage(null)} />

      {editingProduct && (
        <EditProductModal
          product={editingProduct}
          onClose={() => setEditingProduct(null)}
          onUpdate={fetchCatalog}
        />
      )}
    </div>
  );
}
