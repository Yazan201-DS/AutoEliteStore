import { useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";

import styles from "../styles/AdminDashboard.module.css";
import {
  FiHome,
  FiShoppingCart,
  FiUser,
  FiLogOut,
  FiGrid
} from "react-icons/fi";

import Button from "../components/Button";
import EditProfileInfo from "../components/EditProfileInfo";
import ImageModal from "../components/ImageModal";

export default function CustomerDashboard() {
  const [user, setUser] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => {
        if (res.data.user.role === "customer") {
          setUser(res.data.user);
        } else {
          navigate("/auth", { replace: true });
        }
      })
      .catch(() => {
        navigate("/auth", { replace: true });
      });
  }, [navigate]);

  useEffect(() => {
    window.history.pushState(null, null, window.location.href);
    const blockBack = () => {
      window.history.pushState(null, null, window.location.href);
    };
    window.addEventListener("popstate", blockBack);
    return () => window.removeEventListener("popstate", blockBack);
  }, []);

  useEffect(() => {
    const handleEsc = (e) => {
      if (e.key === "Escape") {
        setShowEditModal(false);
        setShowImageModal(false);
      }
    };
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, []);

  const handleLogout = async () => {
  try {
    await axios.post("/api/logout", {}, { withCredentials: true });

    Swal.fire({
      icon: "success",
      title: "Logged out",
      text: "You have successfully logged out.",
      showConfirmButton: false,
      timer: 2000,
    });

    setTimeout(() => {
      navigate("/auth", { replace: true });
    }, 2000);
  } catch (err) {
    console.error("Logout failed", err);
    Swal.fire({
      icon: "error",
      title: "Logout Failed",
      text: "Something went wrong while logging out.",
    });
  }
};


  const handleProfileUpdate = (newFilename) => {
    setUser((prev) => ({ ...prev, profile_picture: newFilename }));
  };

  if (!user) return <div className={styles.dashboard}>Loading...</div>;

  return (
    <div className={styles.dashboardContainer}>
      <aside className={styles.sidebar}>
        <nav className={styles.navLinks}>
          <NavLink to="/customer" className={styles.navItem}>
            <FiHome className={styles.icon} /> Dashboard
          </NavLink>
          <NavLink to="/catalog-overview" className={styles.navItem}>
            <FiGrid className={styles.icon} /> Catalog Overview
          </NavLink>
          <NavLink to="/cart" className={styles.navItem}>
            <FiShoppingCart className={styles.icon} /> My Cart
          </NavLink>
          <NavLink to="/my-orders" className={styles.navItem}>
            <FiShoppingCart className={styles.icon} /> My Orders
          </NavLink>
          <NavLink to="/profile" className={styles.navItem}>
            <FiUser className={styles.icon} /> My Profile
          </NavLink>
          <span
            onClick={handleLogout}
            className={styles.navItem}
            style={{ cursor: "pointer" }}
          >
            <FiLogOut className={styles.icon} /> Logout
          </span>
        </nav>
      </aside>

      <main className={styles.mainContent}>
        <header className={styles.topBar}></header>

        <div className={styles.welcomeHeader}>
          <div className={styles.avatarBox}>
            <img
              src={
                user.profile_picture
                  ? `/images/profiles/${user.profile_picture}`
                  : "/images/default-avatar.png"
              }
              onError={(e) => { e.target.src = "/images/default-avatar.png"; }}
              alt="Profile"
              className={styles.avatar}
              onClick={() => setShowImageModal(true)}
              style={{ cursor: "pointer" }}
            />
          </div>
          <div>
            <h1>Welcome, {user.username}!</h1>
            <p className={styles.subtitle}>Customer Dashboard</p>
            <Button
              text="Edit Profile Info"
              func={() => setShowEditModal(true)}
              className={styles.editButton}
            />
          </div>
        </div>
      </main>

      {showEditModal && (
        <div className={styles.modalBackdrop} onClick={() => setShowEditModal(false)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            <EditProfileInfo user={user} setUser={setUser} />
            <button className={styles.closeBtn} onClick={() => setShowEditModal(false)}>
              ✕
            </button>
          </div>
        </div>
      )}

      {showImageModal && (
        <ImageModal
          imageSrc={
            user.profile_picture
              ? `/images/profiles/${user.profile_picture}`
              : "/images/default-avatar.png"
          }
          onClose={() => setShowImageModal(false)}
        />
      )}
    </div>
  );
}
