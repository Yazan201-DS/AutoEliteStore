import { useState } from "react";
import styles from "../styles/ContactPage.module.css";
import Button from "../components/Button";
import { FaPaperPlane } from "react-icons/fa";

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Message sent successfully!");
    setForm({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <div className={styles.contactPage}>
      <div className={styles.overlay}>
        <form onSubmit={handleSubmit} className={styles.contactBox}>
          <h1>Contact Us</h1>
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            value={form.name}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Your Email"
            value={form.email}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="subject"
            placeholder="Subject"
            value={form.subject}
            onChange={handleChange}
          />
          <textarea
            name="message"
            placeholder="Your Message"
            rows="4"
            value={form.message}
            onChange={handleChange}
            required
          />
          <Button
            type="submit"
            text="Send Message"
            icon={<FaPaperPlane />}
            className={styles.contactBtn}
          />
        </form>
      </div>
    </div>
  );
}
