// Terms.jsx
import styles from "../styles/FooterInfoPages.module.css";

export default function Terms() {
  return (
    <div className={styles.pageContainer}>
      <h1>📜 Terms & Conditions</h1>
      <p>By using this website, you agree to our terms and conditions. We reserve the right to update our terms at any time without prior notice. Please read them carefully before making a purchase.</p>
    </div>
  );
}