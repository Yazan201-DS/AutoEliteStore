import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import styles from "../styles/ManageProducts.module.css";
import Button from "../components/Button";
import EditProductModal from "../components/EditProductModal";

export default function ManageProducts() {
  const [products, setProducts] = useState([]);
  const [imagePreview, setImagePreview] = useState(null);
  const [editingProduct, setEditingProduct] = useState(null);
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [zoomImage, setZoomImage] = useState(null);
  const [isAuthorized, setIsAuthorized] = useState(false);

  const navigate = useNavigate();

  const [newProduct, setNewProduct] = useState({
    name: "", description: "", price: "", category_id: "",
    subcategory_id: "", model_year: "", model_class: "",
    manufacturer_id: "", supplier_id: "", stock_quantity: "", image: null
  });

  // ✅ Admin session check
  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => {
        if (res.data.user.role === "admin") {
          setIsAuthorized(true);
        } else {
          navigate("/login", { replace: true });
        }
      })
      .catch(() => navigate("/login", { replace: true }));
  }, [navigate]);

  const fetchProducts = async () => {
    try {
      const res = await axios.get("/api/products", { withCredentials: true });
      setProducts(res.data);
    } catch (err) {
      console.error("Failed to fetch products", err);
    }
  };

  const fetchDropdownData = async () => {
    try {
      const [cats, mans, sups] = await Promise.all([
        axios.get("/api/categories", { withCredentials: true }),
        axios.get("/api/manufacturers", { withCredentials: true }),
        axios.get("/api/suppliers", { withCredentials: true }),
      ]);
      setCategories(cats.data);
      setManufacturers(mans.data);
      setSuppliers(sups.data);
    } catch (err) {
      console.error("Failed to fetch dropdowns", err);
    }
  };

  useEffect(() => {
    if (newProduct.category_id) {
      axios
        .get(`/api/categories/${newProduct.category_id}/subcategories`, { withCredentials: true })
        .then((res) => setSubcategories(res.data))
        .catch((err) => {
          console.error("Failed to load subcategories", err);
          setSubcategories([]);
        });
    } else {
      setSubcategories([]);
    }
  }, [newProduct.category_id]);

  useEffect(() => {
    if (isAuthorized) {
      fetchProducts();
      fetchDropdownData();
    }
  }, [isAuthorized]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === "category_id") {
      setNewProduct((prev) => ({
        ...prev,
        [name]: value,
        subcategory_id: ""
      }));
    } else {
      setNewProduct((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setNewProduct((prev) => ({ ...prev, image: file }));

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result);
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    Object.entries(newProduct).forEach(([key, value]) => {
      formData.append(key, value);
    });

    try {
      await axios.post("/api/products", formData, {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true,
      });
      await fetchProducts();
      setNewProduct({
        name: "", description: "", price: "", category_id: "",
        subcategory_id: "", model_year: "", model_class: "",
        manufacturer_id: "", supplier_id: "", stock_quantity: "", image: null,
      });
      setImagePreview(null);
      document.querySelector('input[type="file"]').value = '';

      Swal.fire({
        icon: "success",
        title: "Product Added",
        text: "The product was added successfully.",
        timer: 2000,
        showConfirmButton: false,
      });

    } catch (err) {
      console.error("Failed to add product", err);
      Swal.fire({
        icon: "error",
        title: "Error",
        text: "Failed to add the product. Please check the input.",
      });
    }
  };

  const handleDelete = async (productId) => {
    const result = await Swal.fire({
      title: "Delete Product?",
      text: "This action cannot be undone.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    try {
      await axios.delete(`/api/products/${productId}`, { withCredentials: true });
      setProducts((prev) => prev.filter((p) => p.product_id !== productId));
      Swal.fire("Deleted!", "The product has been removed.", "success");
    } catch (err) {
      console.error("Delete failed", err);
      Swal.fire("Error", "Failed to delete the product.", "error");
    }
  };

  if (!isAuthorized) return <div className={styles.container}>Checking access...</div>;

  return (
    <div className={styles.container}>
      <h2>Manage Products</h2>

      <form onSubmit={handleAddProduct} className={styles.form}>
        <input type="text" name="name" placeholder="Product Name" value={newProduct.name} onChange={handleInputChange} required />
        <input type="text" name="description" placeholder="Description" value={newProduct.description} onChange={handleInputChange} required />
        <input type="number" name="price" placeholder="Price" value={newProduct.price} onChange={handleInputChange} required />

        <select name="category_id" value={newProduct.category_id} onChange={handleInputChange} required>
          <option value="">Select Category</option>
          {categories.map(cat => (
            <option key={cat.category_id} value={cat.category_id}>{cat.name}</option>
          ))}
        </select>

        <select name="subcategory_id" value={newProduct.subcategory_id} onChange={handleInputChange}>
          <option value="">Select Subcategory</option>
          {subcategories.map(sub => (
            <option key={sub.subcategory_id} value={sub.subcategory_id}>{sub.name}</option>
          ))}
        </select>

        <input type="number" name="model_year" placeholder="Model Year" value={newProduct.model_year} onChange={handleInputChange} />
        <input type="text" name="model_class" placeholder="Model Class" value={newProduct.model_class} onChange={handleInputChange} />

        <select name="manufacturer_id" value={newProduct.manufacturer_id} onChange={handleInputChange} required>
          <option value="">Select Manufacturer</option>
          {manufacturers.map(m => (
            <option key={m.manufacturer_id} value={m.manufacturer_id}>{m.name}</option>
          ))}
        </select>

        <select name="supplier_id" value={newProduct.supplier_id} onChange={handleInputChange} required>
          <option value="">Select Supplier</option>
          {suppliers.map(s => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
        </select>

        <input type="number" name="stock_quantity" placeholder="Stock Quantity" value={newProduct.stock_quantity} onChange={handleInputChange} required />
        <input type="file" accept="image/*" onChange={handleImageChange} required />

        {imagePreview && <img src={imagePreview} alt="Preview" className={styles.preview} />}
        <Button type="submit" text="Add Product" />
      </form>

      <div className={styles.tableWrapper}>
        <div className={styles.tableHeader}>
          <span>Image</span>
          <span>Name</span>
          <span>Description</span>
          <span>Model</span>
          <span>Year</span>
          <span>Price</span>
          <span>Category</span>
          <span>Subcategory</span>
          <span>Manufacturer</span> {/* ✅ Added */}
          <span>Supplier</span>
          <span>Stock</span>
          <span>Actions</span>
        </div>

        {products.map((prod) => (
          <div className={styles.tableRow} key={prod.product_id}>
            <span className={styles.imageZoomWrapper} onClick={() => setZoomImage(`/images/products/${prod.image}`)}>
              <img src={`/images/products/${prod.image}`} alt={prod.name} className={styles.tableImage} />
            </span>
            <span>{prod.name}</span>
            <span className={styles.descriptionCell}>{prod.description}</span>
            <span>{prod.model_class}</span>
            <span>{prod.model_year}</span>
            <span>${parseFloat(prod.price).toFixed(2)}</span>
            <span>{prod.category_name || "-"}</span>
            <span>{prod.subcategory_name || "-"}</span>
            <span>{prod.manufacturer_name || "-"}</span> {/* ✅ Added */}
            <span>{prod.supplier_name || "-"}</span>
            <span>{prod.stock_quantity}</span>
            <span className={styles.actionCell}>
              <Button text="Edit" className={styles.linkButton} func={() => setEditingProduct(prod)} />
              <Button text="Delete" className={styles.linkButton} func={() => handleDelete(prod.product_id)} />
            </span>
          </div>
        ))}
      </div>

      {editingProduct && (
        <EditProductModal
          product={editingProduct}
          onClose={() => setEditingProduct(null)}
          onUpdate={fetchProducts}
        />
      )}

      {zoomImage && (
        <div className={styles.zoomOverlay} onClick={() => setZoomImage(null)}>
          <img src={zoomImage} alt="Zoomed Product" className={styles.zoomImage} />
        </div>
      )}
    </div>
  );
}
