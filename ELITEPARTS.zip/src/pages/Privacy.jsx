// Privacy.jsx
import styles from "../styles/FooterInfoPages.module.css";

export default function Privacy() {
  return (
    <div className={styles.pageContainer}>
      <h1>🔒 Privacy Policy</h1>
      <p>We value your privacy and are committed to protecting your personal information. We do not share your data with third parties without consent.</p>
    </div>
  );
}