import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import styles from "../styles/signUpIn.module.css";
import Button from "../components/Button";

export default function Signup() {
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    phone: "",
    address: "",
  });
  const [confirmPassword, setConfirmPassword] = useState("");
  const [profilePicture, setProfilePicture] = useState(null);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setError("");

    if (form.password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (!profilePicture) {
      setError("Please upload a profile picture");
      return;
    }

    try {
      const formData = new FormData();
      for (const key in form) {
        formData.append(key, form[key]);
      }

      // ✅ Must match backend field name
      formData.append("profile_picture", profilePicture);

      const res = await axios.post("/api/signup", formData, {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true, // ✅ Store session cookie
      });

      const user = res.data.user;
      navigate(user.role === "admin" ? "/admin" : "/customer");
    } catch (err) {
      console.error(err);
      setError("Signup failed");
    }
  };

  return (
    <div className={styles.authContainer}>
      <div className={styles.formBox}>
        <h2 className={styles.title}>Sign Up</h2>
        <form onSubmit={handleSignup} className={styles.form}>
          <input
            type="text"
            name="username"
            placeholder="Username"
            onChange={handleChange}
            required
            className={styles.input}
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            onChange={handleChange}
            required
            className={styles.input}
          />
          <input
            type="text"
            name="phone"
            placeholder="Phone"
            onChange={handleChange}
            required
            className={styles.input}
          />
          <input
            type="text"
            name="address"
            placeholder="Address"
            onChange={handleChange}
            required
            className={styles.input}
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            onChange={handleChange}
            required
            className={styles.input}
          />
          <input
            type="password"
            placeholder="Confirm Password"
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            className={styles.input}
          />
          <input
            type="file"
            accept="image/*"
            required
            onChange={(e) => setProfilePicture(e.target.files[0])}
            className={styles.input}
          />

          <Button type="submit" text="Sign Up" className={styles.button} />
        </form>
        {error && <p className={styles.error}>{error}</p>}
      </div>
    </div>
  );
}
