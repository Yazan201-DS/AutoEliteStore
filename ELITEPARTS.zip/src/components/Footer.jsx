import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import {
  FaFacebookF,
  FaInstagram,
  FaXTwitter,
  FaLinkedin,
  FaYoutube,
  FaTiktok,
} from "react-icons/fa6";

import styles from "../styles/Footer.module.css";

export default function Footer() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <footer className={styles.footer}>
      <div className={styles.columns}>
        <div className={styles.column}>
          <h4>CUSTOMER CARE</h4>
          <ul>
            <li><NavLink to="/contact">Contact Us</NavLink></li>
            <li><NavLink to="/about">About Us</NavLink></li>
            <li><NavLink to="/terms">Terms & Conditions</NavLink></li>
            <li><NavLink to="/privacy">Privacy Policy</NavLink></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>OUR MANUFACTURERS</h4>
          <ul>
            <li><NavLink to="/manufacturers/mercedesbenz">Mercedes-Benz</NavLink></li>
            <li><NavLink to="/manufacturers/skoda">Skoda</NavLink></li>
            <li><NavLink to="/manufacturers/seat">Seat</NavLink></li>
            <li><NavLink to="/manufacturers/bmw">BMW</NavLink></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>FOLLOW US</h4>
          <div className={styles.socials}>
            <a href="https://instagram.com" target="_blank" rel="noreferrer"><FaInstagram className={styles.icon} /></a>
            <a href="https://facebook.com" target="_blank" rel="noreferrer"><FaFacebookF className={styles.icon} /></a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer"><FaXTwitter className={styles.icon} /></a>
            <a href="https://linkedin.com" target="_blank" rel="noreferrer"><FaLinkedin className={styles.icon} /></a>
            <a href="https://youtube.com" target="_blank" rel="noreferrer"><FaYoutube className={styles.icon} /></a>
            <a href="https://tiktok.com" target="_blank" rel="noreferrer"><FaTiktok className={styles.icon} /></a>
          </div>
        </div>
      </div>

      <div className={styles.datetime}>
        {currentTime.toLocaleDateString()} | {currentTime.toLocaleTimeString()}
      </div>

      <div className={styles.bottomRow}>
        <p>© 2025 Auto Elite Store. Powered by <strong>Yazan & Saed Software Solutions Corp</strong></p>
      </div>
    </footer>
  );
}
