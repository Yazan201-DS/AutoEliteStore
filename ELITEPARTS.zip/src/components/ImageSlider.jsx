import Slider from "react-slick";
import styles from "../styles/ImageSlider.module.css";

const images = [
  "/images/slider/vrs.jpg",
  "/images/slider/vrsinterior.jpg",
  "/images/slider/amgmb.jpg",
  "/images/slider/mbinterior.jpg",
  "/images/slider/cupra.jpg",
  "/images/slider/cuprainterior.jpg",
  "/images/slider/m4bm.jpg",
  "/images/slider/interiorm4.jpg",
];

const captions = [
  "Engineered for precision and lasting performance.",
  "Designed to fit perfectly with OEM specifications.",
  "Trusted by professionals across the automotive industry.",
  "Tested for durability under extreme road conditions.",
  "Upgrade your vehicle with premium-quality components.",
  "Reliable parts, backed by expert craftsmanship.",
  "Crafted to meet the highest safety standards.",
  "Your car deserves parts built to perform.",
];

export default function ImageSlider() {
const settings = {
  dots: false,
  infinite: true,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 3500,
  arrows: false,
  pauseOnHover: false,
};




  return (
    <div className={styles.sliderContainer}>
      <Slider autoplay
  autoplaySpeed={1500}
  pauseOnHover={true}  >
        {images.map((src, index) => (
          <div key={index} className={styles.slide}>
            <img src={src} alt={`Slide ${index + 1}`} className={styles.slideImage} />
            <p className={styles.caption}>{captions[index]}</p>
          </div>
        ))}
      </Slider>
    </div>
  );
}
