import { useState, useEffect } from "react";
import styles from "./ProductSearchBar.module.css";

export default function ProductSearchBar({ 
  categories, 
  subcategories, 
  manufacturers, 
  onChange 
}) {
  const [filters, setFilters] = useState({
    name: "",
    category_id: "",
    subcategory_id: "",
    manufacturer_id: "",
    model_year: "",
    model_class: "",
  });

  // Filter subcategories based on selected category
  const filteredSubcategories = subcategories.filter(
    (sub) => sub.category_id === filters.category_id
  );

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const newFilters = { ...filters, [name]: value };
    setFilters(newFilters);
    onChange(newFilters);  // Pass updated filters to parent
  };

  return (
    <div className={styles.searchBar}>
      <input
        type="text"
        name="name"
        value={filters.name}
        onChange={handleInputChange}
        placeholder="Search by name"
      />

      <select
        name="category_id"
        value={filters.category_id}
        onChange={handleInputChange}
      >
        <option value="">Select Category</option>
        {categories.map((cat) => (
          <option key={cat.id} value={cat.id}>
            {cat.name}
          </option>
        ))}
      </select>

      <select
        name="subcategory_id"
        value={filters.subcategory_id}
        onChange={handleInputChange}
        disabled={!filters.category_id}
      >
        <option value="">Select Subcategory</option>
        {filteredSubcategories.map((sub) => (
          <option key={sub.id} value={sub.id}>
            {sub.name}
          </option>
        ))}
      </select>

      <select
        name="manufacturer_id"
        value={filters.manufacturer_id}
        onChange={handleInputChange}
      >
        <option value="">Select Manufacturer</option>
        {manufacturers.map((manu) => (
          <option key={manu.id} value={manu.id}>
            {manu.name}
          </option>
        ))}
      </select>

      <input
        type="number"
        name="model_year"
        value={filters.model_year}
        onChange={handleInputChange}
        placeholder="Search by Model Year"
      />

      <input
        type="text"
        name="model_class"
        value={filters.model_class}
        onChange={handleInputChange}
        placeholder="Search by Model Class"
      />
    </div>
  );
}
