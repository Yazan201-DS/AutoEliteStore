import { useNavigate } from "react-router-dom";
import ImageSlider from "./ImageSlider";
import Button from "./Button";
import styles from "../styles/HeroSection.module.css";

export default function HeroSection() {
  const navigate = useNavigate();

  const handleExplore = () => {
    navigate("/catalog-overview");
  };

  return (
    <div className={styles.heroContainer}>
      <div className={styles.textSection}>
        
        <h1>Welcome to Auto Elite Stock</h1>        
        <p>
          Discover high-performance parts engineered for excellence.
          From engines to interiors, we stock only the best for your vehicle.
        </p>
        <Button text="Explore Catalog" func={handleExplore} />
      </div>

      <div className={styles.sliderSection}>
        <ImageSlider />
      </div>
    </div>
  );
}
