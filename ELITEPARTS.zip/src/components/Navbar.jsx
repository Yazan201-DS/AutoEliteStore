import { useEffect, useState } from "react";
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import {
  FaHome,
  FaSignInAlt,
  FaPhone,
  FaEnvelope,
  FaUser,
  FaSignOutAlt,
  FaShoppingCart,
  FaBoxOpen,
  FaThList
} from "react-icons/fa";
import { FiGrid } from "react-icons/fi";
import axios from "axios";
import styles from "../styles/navbar.module.css";
import Button from "./Button";

export default function Navbar() {
  const [user, setUser] = useState(null);
  const [currentTime, setCurrentTime] = useState(() => {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  });

  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname;

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then((res) => setUser(res.data.user))
      .catch(() => setUser(null));
  }, []);

  const handleLogout = async () => {
    try {
      await axios.post("/api/logout", {}, { withCredentials: true });
      setUser(null);
      navigate("/auth");
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  const linkClass = ({ isActive }) =>
    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink;

  return (
    <nav className={styles.navbar}>
      <div className={styles.navContent}>
        <div className={styles.logo}>
          <img src="/images/homeimages/logopic.PNG" alt="logo" title="logo" className={styles.logopic} />
          <NavLink to="/" className={styles.logoLink}>
            Auto Elite Stock
          </NavLink>
        </div>

        <ul className={styles.menu}>
          <li>
            <NavLink to="/" className={linkClass}>
              <FaHome className={styles.icon} /> Home
            </NavLink>
          </li>

          {!currentPath.startsWith("/admin") && !currentPath.startsWith("/customer") && (
            <>
              <li>
                <NavLink to="/catalog-overview" className={linkClass}>
                  <FiGrid className={styles.icon} /> Catalog
                </NavLink>
              </li>
              <li>
                <NavLink to="/brands" className={linkClass}>
                  <FaThList className={styles.icon} /> Brands
                </NavLink>
              </li>
            </>
          )}

          <li>
            <NavLink to="/contact" className={linkClass}>
              <FaPhone className={styles.icon} /> Contact
            </NavLink>
          </li>

          <li>
            <NavLink to="/about" className={linkClass}>
              <FaEnvelope className={styles.icon} /> About
            </NavLink>
          </li>

          {/* ✅ Only show auth link when no user is logged in and not on protected pages */}
          {!user && !currentPath.startsWith("/admin") && !currentPath.startsWith("/customer") && (
            <li>
              <NavLink to="/auth" className={linkClass}>
                <FaSignInAlt className={styles.icon} /> Login / Signup
              </NavLink>
            </li>
          )}

          {user?.role === "customer" && (
            <>
              <li>
                <NavLink to="/cart" className={linkClass}>
                  <FaShoppingCart className={styles.icon} /> Cart
                </NavLink>
              </li>
              <li>
                <NavLink to="/orders" className={linkClass}>
                  <FaBoxOpen className={styles.icon} /> My Orders
                </NavLink>
              </li>
              <li>
                <NavLink to="/profile" className={linkClass}>
                  <FaUser className={styles.icon} /> Profile
                </NavLink>
              </li>
              <li>
                <Button
                  text="Logout"
                  icon={<FaSignOutAlt />}
                  func={handleLogout}
                  className={styles.logoutBtn}
                />
              </li>
            </>
          )}

          {user?.role === "admin" && (
            <li>
              <Button
                text="Logout"
                icon={<FaSignOutAlt />}
                func={handleLogout}
                className={styles.logoutBtn}
              />
            </li>
          )}
        </ul>
      </div>
    </nav>
  );
}
