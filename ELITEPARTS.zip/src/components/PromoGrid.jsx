import styles from '../styles/PromoGrid.module.css';
import Button from './Button';

export default function PromoGrid({ title, description, category, imageUrl, imageFirst = true }) {
  return (
    <div className={`${styles.gridContainer} ${imageFirst ? styles.imageLeft : styles.imageRight}`}>
      <div className={styles.imageWrapper}>
        <img
          src={imageUrl}
          alt={title}
          className={styles.image}
          onError={(e) => {
            e.target.src = "/images/default-avatar.png";
          }}
        />
      </div>
      <div className={styles.content}>
        <p className={styles.category}>{category}</p>
        <h2 className={styles.title}>{title}</h2>
        <p className={styles.description}>{description}</p>
        <Button text="Learn more" func={() => {}} />
      </div>
    </div>
  );
}
