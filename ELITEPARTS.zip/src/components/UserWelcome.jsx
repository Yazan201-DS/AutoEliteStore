import { useState } from "react";
import styles from "../styles/UserWelcome.module.css";
import ImageModal from "./ImageModal";

export default function UserWelcome({ user }) {
  const isAdmin = user?.role === "admin";
  const isCustomer = user?.role === "customer";
  const [showImageModal, setShowImageModal] = useState(false);

  if (!isAdmin && !isCustomer) return null;

  const imageSrc = user.profile_picture
    ? `/images/profiles/${user.profile_picture}`
    : "/images/default-avatar.png";

  return (
    <div className={styles.welcomeBox}>
      <img
        src={imageSrc}
        alt="Profile"
        onError={(e) => (e.target.src = "/images/default-avatar.png")}
        className={styles.profilePic}
        onClick={() => setShowImageModal(true)}
        style={{ cursor: "zoom-in" }}
      />
      <div>
        <h2 className={styles.h2welcome}>
          <span className={styles.typing}>
            Welcome {isAdmin ? "Admin" : "Customer"},{" "}
            <span className={styles.username}>{user.username}</span>!
          </span>
        </h2>

        <p className={styles.message}>
          {isAdmin
            ? "Quick access to product management, categories, and supplier tools."
            : "Check your cart, orders, and update your profile for a better shopping experience."}
        </p>
      </div>

      {showImageModal && (
        <ImageModal imageSrc={imageSrc} onClose={() => setShowImageModal(false)} />
      )}
    </div>
  );
}
