import styles from "../styles/CatalogOverview.module.css";
import { FiSearch, FiTag, FiList, FiFilter } from "react-icons/fi";
import Button from "./Button";

export default function CatalogSearch({
  searchTerm,
  setSearchTerm,
  selectedBrand,
  setSelectedBrand,
  selectedCategory,
  setSelectedCategory,
  selectedSubcategory,
  setSelectedSubcategory,
  selectedModelYear,
  setSelectedModelYear,
  selectedModelClass,
  setSelectedModelClass,
  data,
  onClearFilters, // ✅ NEW prop
}) {
  const categoryOptions = [
    ...new Set(data.flatMap((brand) =>
      brand.categories.map((cat) => cat.categoryName)
    )),
  ];

  const subcategoryOptions = [
    ...new Set(data.flatMap((brand) =>
      brand.categories.flatMap((cat) =>
        cat.products.map((p) => p.subcategory_name).filter(Boolean)
      )
    )),
  ];

  const modelYearOptions = [
    ...new Set(data.flatMap((brand) =>
      brand.categories.flatMap((cat) =>
        cat.products.map((p) => p.model_year).filter(Boolean)
      )
    )),
  ];

  const modelClassOptions = [
    ...new Set(data.flatMap((brand) =>
      brand.categories.flatMap((cat) =>
        cat.products.map((p) => p.model_class).filter(Boolean)
      )
    )),
  ];

  return (
    <div className={styles.filterBar}>
      <div className={styles.inputWithIcon}>
        <FiSearch className={styles.icon} />
        <input
          type="text"
          placeholder="Search name or description"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className={styles.searchInput}
        />
      </div>

      <div className={styles.inputWithIcon}>
        <FiFilter className={styles.icon} />
        <select value={selectedBrand} onChange={(e) => setSelectedBrand(e.target.value)}>
          <option value="">All Brands</option>
          {data.map((brand) => (
            <option key={brand.brandName} value={brand.brandName}>{brand.brandName}</option>
          ))}
        </select>
      </div>

      <div className={styles.inputWithIcon}>
        <FiTag className={styles.icon} />
        <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
          <option value="">All Categories</option>
          {categoryOptions.map((cat) => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      <div className={styles.inputWithIcon}>
        <FiList className={styles.icon} />
        <select value={selectedSubcategory} onChange={(e) => setSelectedSubcategory(e.target.value)}>
          <option value="">All Subcategories</option>
          {subcategoryOptions.map((sub) => (
            <option key={sub} value={sub}>{sub}</option>
          ))}
        </select>
      </div>

      <div className={styles.inputWithIcon}>
        <FiFilter className={styles.icon} />
        <select value={selectedModelYear} onChange={(e) => setSelectedModelYear(e.target.value)}>
          <option value="">All Model Years</option>
          {modelYearOptions.map((year) => (
            <option key={year} value={year}>{year}</option>
          ))}
        </select>
      </div>

      <div className={styles.inputWithIcon}>
        <FiFilter className={styles.icon} />
        <select value={selectedModelClass} onChange={(e) => setSelectedModelClass(e.target.value)}>
          <option value="">All Model Classes</option>
          {modelClassOptions.map((mc) => (
            <option key={mc} value={mc}>{mc}</option>
          ))}
        </select>
      </div>

      {/* ✅ Clear Filters Button */}
      <div>
        <Button text="Clear All Filters" func={onClearFilters} className={styles.clearButton} />
      </div>
    </div>
  );
}
