import { useEffect, useState } from "react";
import axios from "axios";
import styles from "../styles/AdminStatsPanel.module.css";

export default function AdminStatsPanel() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    axios
      .get("/api/statistics/overview", { withCredentials: true })
      .then((res) => setStats(res.data))
      .catch((err) => console.error("Failed to fetch overview stats", err));
  }, []);

  if (!stats) return <p>Loading admin stats...</p>;

  const barData = [
    { label: "Users", value: stats.totalUsers, color: "#00f2ff", max: 100 },
    { label: "Orders", value: stats.totalOrders, color: "#ffe100", max: 50 },
    { label: "Sold", value: stats.totalProductsSold, color: "#e100ff", max: 100 },
    { label: "Revenue", value: stats.totalRevenue, color: "#00ff9d", max: 1000 },
    { label: "Inventory", value: stats.totalProductsInStore, color: "#4299ff", max: 100 }, // Number of products
    { label: "Stock Quantity", value: stats.totalStockQuantity, color: "#ff69b4", max: 10000000 }, // Total units in store
    { label: "Out of Stock", value: stats.outOfStockCount, color: "#ff5b5b", max: 20 },
  ];

  return (
    <div className={styles.panelContainer}>
      <h2 className={styles.header}>Admin Overview</h2>
      <div className={styles.barList}>
        {barData.map((item, i) => (
          <div key={i} className={styles.barWrapper}>
            <div className={styles.labelRow}>
              <span>{item.label}</span>
              <span>{item.value}</span>
            </div>
            <div className={styles.barBg}>
              <div
                className={styles.barFill}
                style={{
                  width: `${(item.value / item.max) * 100}%`,
                  backgroundColor: item.color,
                  boxShadow: `0 0 12px ${item.color}`,
                }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
