import { NavLink } from "react-router-dom";
import styles from "../styles/HomeCompo.module.css";

export default function HomeCompo() {
  
}
