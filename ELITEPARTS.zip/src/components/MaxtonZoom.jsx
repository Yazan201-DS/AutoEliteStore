import { useState, useEffect } from "react";
import styles from "../styles/MaxtonZoom.module.css";

export default function MaxtonZoom() {
  const [zoomed, setZoomed] = useState(false);

  const handleKeyDown = (e) => {
    if (e.key === "Escape") {
      setZoomed(false);
    }
  };

  useEffect(() => {
    if (zoomed) {
      window.addEventListener("keydown", handleKeyDown);
    } else {
      window.removeEventListener("keydown", handleKeyDown);
    }
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [zoomed]);

  return (
    <>
      <div className={styles.row}>
        <div className={styles.maxton} onClick={() => setZoomed(true)}>
          <img src="/images/homeimages/vrsmaxton.jpg" alt="vrs2019" title="Maxton Design" />
        </div>

        <div className={styles.textbox}>
          <h3>Maxton Design Body Kit</h3>
          <p>
            Maxton Design specializes in aerodynamic parts designed for a sportier and more aggressive look.
            Their high-quality body kits enhance performance and style for various car models.
            This particular kit fits the Škoda Octavia vRS and includes front splitters, side skirts, and a rear diffuser.
          </p>
        </div>
      </div>

      {zoomed && (
        <div className={styles.zoomOverlay} onClick={() => setZoomed(false)}>
          <img
            src="/images/homeimages/vrsmaxton.jpg"
            alt="vrs2019"
            className={styles.zoomImage}
          />
        </div>
      )}
    </>
  );
}
