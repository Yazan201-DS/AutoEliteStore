import styles from "../styles/ImageModal.module.css";

export default function ImageModal({ imageSrc, onClose }) {
  if (!imageSrc) return null;

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <img src={imageSrc} alt="Full Preview" />
        <button onClick={onClose} className={styles.closeButton}>✕</button>
      </div>
    </div>
  );
}
