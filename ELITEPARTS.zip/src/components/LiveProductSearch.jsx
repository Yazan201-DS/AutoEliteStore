import { useState, useEffect } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import styles from "../styles/LiveProductSearch.module.css";
import ImageModal from "./ImageModal";
import Button from "./Button";
import EditProductModal from "./EditProductModal";

export default function LiveProductSearch() {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [user, setUser] = useState(null);
  const [zoomImage, setZoomImage] = useState(null);
  const [quantities, setQuantities] = useState({});
  const [editingProduct, setEditingProduct] = useState(null);

  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => setUser(res.data.user))
      .catch(() => setUser(null));
  }, []);

  const fetchSearchResults = async () => {
    try {
      const res = await axios.get(`/api/products/search?term=${encodeURIComponent(searchTerm)}`);
      setSearchResults(res.data);
    } catch {
      setSearchResults([]);
    }
  };

  useEffect(() => {
    if (searchTerm.trim().length > 1) {
      fetchSearchResults();
    } else {
      setSearchResults([]);
    }
  }, [searchTerm]);

  const handleQtyChange = (id, value) => {
    const val = parseInt(value);
    setQuantities(prev => ({ ...prev, [id]: isNaN(val) || val < 1 ? 1 : val }));
  };

  const handleAddToCart = async (product_id) => {
    const quantity = quantities[product_id] || 1;
    try {
      await axios.post("/api/cart", { product_id, quantity }, { withCredentials: true });
      Swal.fire({
        title: "Added to Cart!",
        text: "The product was added successfully.",
        icon: "success",
        timer: 1800,
        showConfirmButton: false
      });
    } catch (err) {
      console.error("Add to cart failed", err);
      Swal.fire({
        title: "Oops!",
        text: "Failed to add item to cart.",
        icon: "error"
      });
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
  };

  const handleDelete = async (product_id) => {
    const confirm = await Swal.fire({
      title: "Are you sure?",
      text: "This will permanently delete the product.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#e60023",
      cancelButtonColor: "#333",
      confirmButtonText: "Yes, delete it"
    });

    if (confirm.isConfirmed) {
      try {
        await axios.delete(`/api/products/${product_id}`, { withCredentials: true });
        setSearchResults(prev => prev.filter(p => p.product_id !== product_id));
        Swal.fire({
          title: "Deleted!",
          text: "Product was removed.",
          icon: "success",
          timer: 1600,
          showConfirmButton: false
        });
      } catch (err) {
        console.error("Delete error:", err);
        Swal.fire({
          title: "Error",
          text: "Failed to delete product.",
          icon: "error"
        });
      }
    }
  };

  return (
    <div className={styles.searchContainer}>
      <input
        type="text"
        placeholder="Search by name or description ..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className={styles.searchInput}
      />

      {searchResults.length > 0 && (
        <div className={styles.cardGrid}>
          {searchResults.map(product => (
            <div key={product.product_id} className={styles.card}>
              <img
                src={`/images/products/${product.image}`}
                alt={product.name}
                className={styles.cardImage}
                onClick={() => setZoomImage(`/images/products/${product.image}`)}
                onError={(e) => { e.target.src = "/images/default-image.jpg"; }}
              />
              <h3 className={styles.cardTitle}>{product.name}</h3>
              <p className={styles.cardPrice}>${Number(product.price).toFixed(2)}</p>
              <p className={styles.cardInfo}><strong>Model:</strong> {product.model_class || "N/A"}</p>
              <p className={styles.cardInfo}><strong>Year:</strong> {product.model_year || "N/A"}</p>
              <p className={styles.cardInfo}><strong>Stock:</strong> {product.stock_quantity}</p>
              <p className={styles.cardDescription}>{product.description}</p>

              {user?.role === "customer" && (
                <div className={styles.actions}>
                  <input
                    type="number"
                    min="1"
                    value={quantities[product.product_id] || 1}
                    onChange={(e) => handleQtyChange(product.product_id, e.target.value)}
                    className={styles.qtyInput}
                  />
                  <Button text="Add to Cart" func={() => handleAddToCart(product.product_id)} />
                </div>
              )}

              {user?.role === "admin" && (
                <div className={styles.actions}>
                  <Button text="Edit" func={() => handleEdit(product)} />
                  <Button text="Delete" func={() => handleDelete(product.product_id)} />
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {zoomImage && (
        <ImageModal imageSrc={zoomImage} onClose={() => setZoomImage(null)} />
      )}

      {editingProduct && (
        <EditProductModal
          product={editingProduct}
          onClose={() => setEditingProduct(null)}
          onUpdate={() => {
            fetchSearchResults();
            setEditingProduct(null);
          }}
        />
      )}
    </div>
  );
}
