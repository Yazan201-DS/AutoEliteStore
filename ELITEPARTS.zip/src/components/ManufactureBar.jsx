import styles from '../styles/manufBar.module.css';
import { NavLink } from "react-router-dom";

export default function ManufactureBar() {
  const brands = [
    { slug: "mercedesbenz", label: "Mercedes-Benz", img: "mercedesbenzz.png" },
    { slug: "skoda", label: "Skoda", img: "skodaa.png" },
    { slug: "seat", label: "Seat", img: "seatt.png" },
    { slug: "bmw", label: "BMW", img: "bmww.png" },
  ];

  return (
    <div className={styles.heroSection}>
      <ul className={styles.brandList}>
        {brands.map((brand) => (
          <li key={brand.slug} className={styles.brandItem}>
            <NavLink to={`/manufacturers/${brand.slug}`} className={styles.link}>
              <img
                src={`/images/manufacturers/${brand.img}`}
                alt={brand.label}
                className={styles.brandImage}
              />
            </NavLink>
          </li>
        ))}
      </ul>
    </div>
  );
}
