import { FaInstagram, FaFacebook, FaXTwitter, FaLinkedin, FaYoutube, FaTiktok } from "react-icons/fa6";
import styles from "../styles/SocialIcons.module.css";

export default function SocialIcons() {
  return (
    <div className={styles.iconRow}>
      <a href="https://instagram.com" target="_blank" rel="noreferrer">
        <FaInstagram className={styles.icon} />
      </a>
      <a href="https://facebook.com" target="_blank" rel="noreferrer">
        <FaFacebook className={styles.icon} />
      </a>
      <a href="https://twitter.com" target="_blank" rel="noreferrer">
        <FaXTwitter className={styles.icon} />
      </a>
      <a href="https://linkedin.com" target="_blank" rel="noreferrer">
        <FaLinkedin className={styles.icon} />
      </a>
      <a href="https://youtube.com" target="_blank" rel="noreferrer">
        <FaYoutube className={styles.icon} />
      </a>
      <a href="https://tiktok.com" target="_blank" rel="noreferrer">
        <FaTiktok className={styles.icon} />
      </a>
    </div>
  );
}
