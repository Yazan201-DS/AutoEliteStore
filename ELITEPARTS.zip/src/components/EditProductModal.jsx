import { useState, useEffect } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import styles from "../styles/EditProductModal.module.css";
import Button from "./Button";

export default function EditProductModal({ product, onClose, onUpdate }) {
  const [form, setForm] = useState({ ...product });
  const [imagePreview, setImagePreview] = useState(null);
  const [newImage, setNewImage] = useState(null);

  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [manufacturers, setManufacturers] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setForm({ ...product });
    setImagePreview(`/images/products/${product.image}`);

    axios.get("/api/categories").then(res => setCategories(res.data));
    axios.get("/api/manufacturers").then(res => setManufacturers(res.data));
    axios.get("/api/suppliers").then(res => setSuppliers(res.data));

    if (product.category_id) {
      axios
        .get(`/api/categories/${product.category_id}/subcategories`)
        .then(res => setSubcategories(res.data))
        .catch(() => setSubcategories([]));
    }
  }, [product]);

  useEffect(() => {
    if (form.category_id) {
      axios
        .get(`/api/categories/${form.category_id}/subcategories`)
        .then(res => setSubcategories(res.data))
        .catch(() => setSubcategories([]));
    } else {
      setSubcategories([]);
    }
  }, [form.category_id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "category_id") {
      setForm(prev => ({ ...prev, category_id: value, subcategory_id: "" }));
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setNewImage(file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const price = parseFloat(form.price);
    const stock = parseInt(form.stock_quantity);
    const modelYear = parseInt(form.model_year);

    if (price <= 0) {
      Swal.fire("Invalid", "Price must be greater than 0", "warning");
      return;
    }

    if (stock <= 0) {
      Swal.fire("Invalid", "Stock quantity must be greater than 0", "warning");
      return;
    }

    if (modelYear && (modelYear < 2000 || modelYear > 2026)) {
      Swal.fire("Invalid", "Model year must be between 2000 and 2026", "warning");
      return;
    }

    const formData = new FormData();
    Object.entries(form).forEach(([key, value]) => {
      formData.append(key, value);
    });
    if (newImage) formData.append("image", newImage);

    setLoading(true);

    try {
      await axios.put(`/api/products/${product.product_id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      onUpdate();
      Swal.fire("Success", "Product updated successfully", "success");
      onClose();
      setNewImage(null);
      setImagePreview(null);
    } catch (err) {
      console.error("Update failed", err);
      Swal.fire("Error", "Failed to update product", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.modalBackdrop}>
      <div className={styles.modal}>
        <h2>Edit Product</h2>
        <form onSubmit={handleSubmit} className={styles.form}>
          <input type="text" name="name" value={form.name} onChange={handleChange} placeholder="Name" required />
          <input type="text" name="description" value={form.description} onChange={handleChange} placeholder="Description" required />
          <input type="number" name="price" value={form.price} onChange={handleChange} placeholder="Price" required />

          <select name="category_id" value={form.category_id} onChange={handleChange} required>
            <option value="">Select Category</option>
            {categories.map(cat => (
              <option key={cat.category_id} value={cat.category_id}>{cat.name}</option>
            ))}
          </select>

          <select name="subcategory_id" value={form.subcategory_id || ""} onChange={handleChange} disabled={!subcategories.length}>
            <option value="">Select Subcategory</option>
            {subcategories.map(sub => (
              <option key={sub.subcategory_id} value={sub.subcategory_id}>{sub.name}</option>
            ))}
          </select>

          <input type="number" name="model_year" value={form.model_year || ""} onChange={handleChange} placeholder="Model Year" />
          <input type="text" name="model_class" value={form.model_class || ""} onChange={handleChange} placeholder="Model Class" />

          <select name="manufacturer_id" value={form.manufacturer_id} onChange={handleChange} required>
            <option value="">Select Manufacturer</option>
            {manufacturers.map(m => (
              <option key={m.manufacturer_id} value={m.manufacturer_id}>{m.name}</option>
            ))}
          </select>

          <select name="supplier_id" value={form.supplier_id} onChange={handleChange} required>
            <option value="">Select Supplier</option>
            {suppliers.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>

          <input type="number" name="stock_quantity" value={form.stock_quantity} onChange={handleChange} placeholder="Stock Quantity" required />
          <input type="file" accept="image/*" onChange={handleImageChange} />

          {imagePreview && <img src={imagePreview} alt="Preview" className={styles.preview} />}

          <div className={styles.actions}>
            {loading ? (
              <Button text="Saving..." disabled />
            ) : (
              <>
                <Button text="Save" type="submit" />
                <Button text="Cancel" func={onClose} className={styles.cancel} />
              </>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
