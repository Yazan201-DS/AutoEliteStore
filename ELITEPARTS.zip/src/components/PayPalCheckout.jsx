import { useEffect, useRef, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function PayPalCheckout({ cartItems, total, user, setCartItems }) {
  const [processing, setProcessing] = useState(false);
  const paypalRef = useRef();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user || !user.user_id) {
      console.warn("PayPalCheckout blocked — user not logged in");
      return;
    }

    if (!cartItems.length || total <= 0) {
      console.warn("PayPalCheckout skipped — empty cart or total:", total);
      return;
    }

    if (paypalRef.current.hasChildNodes()) return;

    const paypalButtons = window.paypal.Buttons({
      createOrder: (data, actions) => {
        console.log("Creating PayPal order for:", total);
        return actions.order.create({
          purchase_units: [
            {
              amount: {
                value: total.toFixed(2),
              },
            },
          ],
        });
      },

      onApprove: async (data, actions) => {
        setProcessing(true); // ⛔️ disable PayPal button
        const details = await actions.order.capture();
        console.log("PayPal payment captured:", details);

        const orderPayload = {
          cart: cartItems.map((item) => ({
            id: item.product_id,
            quantity: item.quantity,
          })),
          paypal_id: details.id,
          total_price: total,
        };

        console.log("Sending order to /api/orders:", orderPayload);

        try {
          const res = await axios.post("/api/orders", orderPayload, {
            withCredentials: true,
          });

          toast.success("Order placed successfully!");

          if (setCartItems) setCartItems([]); // frontend clear
          await axios.delete("/api/cart/clear", { withCredentials: true }); // backend clear

          navigate("/order-success", {
            state: { order_id: res.data.order_id },
          });
        } catch (err) {
          console.error("Order submission failed:", err.response?.data || err);
          toast.error("Failed to place order. Please try again.");
        } finally {
          setProcessing(false);
        }
      },

      onError: (err) => {
        console.error("PayPal error:", err);
        toast.error("Payment failed. Please try again.");
      },

      onClick: () => {
        if (processing) {
          console.warn("Checkout in progress, ignoring click");
          return false;
        }
      },
    });

    paypalButtons.render(paypalRef.current);

    return () => {
      paypalRef.current.innerHTML = "";
    };
  }, [cartItems, total, user, navigate, setCartItems, processing]);

  if (!user || !user.user_id) {
    return <div>Please log in to proceed with checkout.</div>;
  }

  if (!cartItems.length || total <= 0) {
    return <div>Your cart is empty. Please add items before checking out.</div>;
  }

  return (
    <div>
      {processing && <p>Processing your order...</p>}
      <div ref={paypalRef} />
    </div>
  );
}
