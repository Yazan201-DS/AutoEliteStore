import { useState } from "react";
import axios from "axios";
import ProfileImageUploader from "./ProfileImageUploader";
import styles from "../styles/EditProfileInfo.module.css";
import Button from "./Button";

export default function EditProfileInfo({ user, setUser }) {
  const [form, setForm] = useState({
    name: user.name,
    phone: user.phone,
    address: user.address,
  });

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    try {
      // ✅ 1. Update basic info
      await axios.put(`/api/users/${user.user_id}`, form);
      const updated = { ...user, ...form };
      localStorage.setItem("user", JSON.stringify(updated));
      setUser(updated);

      // ✅ 2. Update password only if both fields provided
      if (currentPassword && newPassword) {
        if (newPassword.length < 6) {
          setMessage("New password must be at least 6 characters");
          return;
        }

        await axios.put(`/api/users/${user.user_id}/password`, {
          currentPassword,
          newPassword,
        });
      }

      setMessage("Profile updated successfully");
      setCurrentPassword("");
      setNewPassword("");
    } catch (err) {
      console.error("Update error:", err);
      if (err.response?.data?.message) {
        setMessage(err.response.data.message);
      } else {
        setMessage("Failed to update profile");
      }
    }
  };

  const handleProfileUpdate = (newFilename) => {
    const updated = { ...user, profile_picture: newFilename };
    localStorage.setItem("user", JSON.stringify(updated));
    setUser(updated);
    setMessage("Profile picture updated successfully");
  };

  return (
    <div className={styles.editProfileContainer}>
      <h2>Edit Profile</h2>

      <ProfileImageUploader
        currentImage={user.profile_picture}
        userId={user.user_id}
        onUpdate={handleProfileUpdate}
      />

      <div className={styles.formGroup}>
        <label>Name</label>
        <input
          type="text"
          name="name"
          value={form.name}
          onChange={handleChange}
          className={styles.input}
        />
      </div>

      <div className={styles.formGroup}>
        <label>Phone</label>
        <input
          type="text"
          name="phone"
          value={form.phone}
          onChange={handleChange}
          className={styles.input}
        />
      </div>

      <div className={styles.formGroup}>
        <label>Address</label>
        <input
          type="text"
          name="address"
          value={form.address}
          onChange={handleChange}
          className={styles.input}
        />
      </div>

      <div className={styles.formGroup}>
        <label>Current Password</label>
        <input
          type={showPassword ? "text" : "password"}
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          className={styles.input}
        />
      </div>

      <div className={styles.formGroup}>
        <label>New Password</label>
        <input
          type={showPassword ? "text" : "password"}
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className={styles.input}
        />
      </div>

      <div className={styles.toggleBox}>
        <label>
          <input
            type="checkbox"
            checked={showPassword}
            onChange={() => setShowPassword((prev) => !prev)}
          />{" "}
          Show Passwords
        </label>
      </div>

      <Button text="Save Changes" func={handleSave} className={styles.saveButton} />
      {message && <p className={styles.message}>{message}</p>}
    </div>
  );
}
