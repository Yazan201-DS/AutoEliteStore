import { useState, useEffect, useRef } from "react";
import styles from "../styles/Modal.module.css";
import Button from "./Button";
import axios from "axios";
import Swal from "sweetalert2";

export default function EditCategoryModal({ category, onClose, onUpdate }) {
  const [name, setName] = useState(category.name);
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(`/images/categories/${category.image}`);
  const fileInputRef = useRef();

  useEffect(() => {
    setName(category.name);
    setImage(null);
    setImagePreview(`/images/categories/${category.image}`);
  }, [category]);

  const handleImageChange = (file) => {
    setImage(file);
    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result);
    reader.readAsDataURL(file);
  };

  const handleFileInputChange = (e) => {
    if (e.target.files[0]) {
      handleImageChange(e.target.files[0]);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) {
      handleImageChange(file);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

      if (name === category.name && !image) {
    Swal.fire("No Changes", "Nothing to update", "info");
    return;
  }

    const formData = new FormData();
    formData.append("name", name);
    if (image) formData.append("image", image);

    try {
      await axios.put(`/api/categories/${category.category_id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      onUpdate();
      onClose(); // auto-reset
      Swal.fire("Updated!", "Category updated successfully", "success");
    } catch (err) {
      console.error("Update failed:", err);
      Swal.fire("Error", "Failed to update category", "error");
    }
  };

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div
        className={styles.modal}
        onClick={(e) => e.stopPropagation()}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        <h3>Edit Category</h3>
        <form onSubmit={handleSubmit} className={styles.form}>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileInputChange}
            style={{ display: "none" }}
          />
          <div
            className={styles.dropArea}
            onClick={() => fileInputRef.current.click()}
          >
            <p>Click or drag an image here to update</p>
            {imagePreview && (
              <img
                src={imagePreview}
                alt="Preview"
                className={styles.previewImage}
              />
            )}
          </div>
          <div className={styles.actions}>
            <Button text="Update" type="submit" />
            <Button text="Cancel" func={onClose} className={styles.cancel} />
          </div>
        </form>
      </div>
    </div>
  );
}
