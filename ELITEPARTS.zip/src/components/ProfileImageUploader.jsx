import { useRef, useState } from "react";
import axios from "axios";
import styles from "../styles/ProfileImageUploader.module.css";

export default function ProfileImageUploader({ currentImage, userId, onUpdate }) {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);

    try {
      const formData = new FormData();
      formData.append("profile_picture", file);

      const res = await axios.put(`/api/users/${userId}/profile_picture`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (onUpdate) {
        onUpdate(res.data.filename); // ✅ update parent with new filename
      }
    } catch (err) {
      console.error("Failed to upload profile picture:", err);
      alert("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const handleClick = () => {
    fileInputRef.current.click();
  };

  return (
    <div className={styles.uploaderContainer}>
      <div className={styles.imagePreview} onClick={handleClick}>
        <img
          src={
            currentImage
              ? `/images/profiles/${currentImage}`
              : "/images/default-avatar.png"
          }
          onError={(e) => { e.target.src = "/images/default-avatar.png"; }}
          alt="Profile"
          className={styles.profileImage}
        />
        <div className={styles.overlay}>
          {uploading ? "Uploading..." : "Click to change"}
        </div>
      </div>

      <input
        type="file"
        accept="image/*"
        ref={fileInputRef}
        onChange={handleFileChange}
        style={{ display: "none" }}
      />
    </div>
  );
}
