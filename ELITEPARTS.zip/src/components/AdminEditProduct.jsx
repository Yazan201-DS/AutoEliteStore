import { useState, useEffect } from "react";
import styles from "../styles/BrandPages.module.css";

export default function AdminEditProduct({ product, onClose, onSave }) {
  const [form, setForm] = useState({});

  useEffect(() => {
    setForm(product);
  }, [product]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    onSave(form); // Send changes to parent
    onClose();    // Close modal
  };

  return (
    <div className={styles.modalOverlay}>
      <div className={styles.modalContent}>
        <h2>Edit Product</h2>

        <label htmlFor="name">Name</label>
        <input
          name="name"
          value={form.name || ""}
          onChange={handleChange}
        />

        <label htmlFor="price">Price</label>
        <input
          name="price"
          type="number"
          value={form.price || ""}
          onChange={handleChange}
        />

        <label htmlFor="stock_quantity">Stock Quantity</label>
        <input
          name="stock_quantity"
          type="number"
          value={form.stock_quantity || ""}
          onChange={handleChange}
        />

        <div className={styles.modalActions}>
          <button onClick={handleSubmit}>Save</button>
          <button onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
