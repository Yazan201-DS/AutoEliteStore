import styles from '../styles/Button.module.css';

export default function Button({ text, type = "button", func, className = "" }) {
  return (
    <button
      type={type}
      onClick={func}
      className={`${styles.button} ${className}`.trim()}
    >
      {text}
    </button>
  );
}
