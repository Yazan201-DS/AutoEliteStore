import { useEffect, useState } from "react";
import axios from "axios";
import styles from "../styles/LowStockManager.module.css";
import Button from "../components/Button"; // ✅ using your custom Button

export default function LowStockManager() {
  const [lowStock, setLowStock] = useState([]);
  const [updateValues, setUpdateValues] = useState({});
  const [loading, setLoading] = useState(false);

  const fetchLowStock = async () => {
    try {
      const res = await axios.get("/api/statistics/low-stock-products", {
        withCredentials: true,
      });
      setLowStock(res.data);
    } catch (err) {
      console.error("❌ Failed to fetch low stock:", err);
    }
  };

  useEffect(() => {
    fetchLowStock();
  }, []);

  const handleChange = (id, value) => {
    setUpdateValues((prev) => ({ ...prev, [id]: value }));
  };

  const handleUpdate = async (id) => {
    const quantity = updateValues[id];
    if (!quantity || isNaN(quantity) || quantity < 0) return;

    setLoading(true);
    try {
      await axios.put(
        `/api/statistics/products/${id}/quantity`,
        { quantity: parseInt(quantity) },
        { withCredentials: true }
      );
      fetchLowStock();
      setUpdateValues((prev) => ({ ...prev, [id]: "" }));
    } catch (err) {
      console.error("❌ Failed to update quantity:", err);
    } finally {
      setLoading(false);
    }
  };

  if (lowStock.length === 0) return null;

  return (
    <div className={styles.container}>
      <h3 className={styles.title}>⚠️ Low Stock Products</h3>
      <div className={styles.list}>
        {lowStock.map((product) => (
          <div key={product.product_id} className={styles.item}>
            <span className={styles.name}>{product.name}</span>
            <span className={styles.qty}>Current: {product.stock_quantity}</span>
            <input
              type="number"
              placeholder="New Qty"
              value={updateValues[product.product_id] || ""}
              onChange={(e) =>
                handleChange(product.product_id, e.target.value)
              }
              className={styles.input}
            />
            <Button
              text="Update"
              func={() => handleUpdate(product.product_id)}
              className={styles.updateBtn}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
