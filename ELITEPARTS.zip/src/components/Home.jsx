import { useEffect, useState } from "react";
import { useNavigate ,NavLink} from "react-router-dom";
import axios from "axios";
import LiveProductSearch from "../components/LiveProductSearch";
import MaxtonZoom from "../components/MaxtonZoom";

import styles from "../styles/hero.module.css";
import ImageSlider from "./ImageSlider";
import PromoGrid from "./PromoGrid";
import UserWelcome from "./UserWelcome"; // ✅ import the new component

export default function Home() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("/api/me", { withCredentials: true })
      .then(res => setUser(res.data.user))
      .catch(() => setUser(null));
  }, []);

  const handleExploreClick = () => {
    navigate("/catalog-overview");
  };

  return (
    <div>
      <div>
       
          <LiveProductSearch />
   {/* ✅ Personalized User Welcome using PromoGrid styling */}
        {user && <UserWelcome user={user} />}
      
      </div>

      <div className={styles.heroContainer}>
    

        {/* ✅ Slider First */}
        <div className={styles.sliderSection}>
          <ImageSlider />
        </div>
       
          
        {/* ✅ Generic Promo Sections */}
        <div className={styles.promoSection}>
  <PromoGrid
    category="Buy and Drive"
    title="AUTO ELITE CUSTOMER EXPERIENCE"
    description="Discover unmatched service at Auto Elite — from expert advice on spare parts to personalized support for every vehicle model."
    imageUrl="/images/homeimages/experience.jpg"
    imageFirst={true}
  />
  <PromoGrid
    category="transmission"
    title="CERTIFIED ORIGINAL SPARE PARTS"
    description="At Auto Elite, we guarantee authenticity. All our products are verified and sourced from trusted suppliers."
    imageUrl="/images/homeimages/dsg.jpg"
    imageFirst={false}
  />
</div>

        
        <MaxtonZoom />
   
      </div>

    </div>
  );
}
