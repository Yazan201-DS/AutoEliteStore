-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: אוגוסט 02, 2025 בזמן 06:42 PM
-- גרסת שרת: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autoeliteplus`
--

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- הוצאת מידע עבור טבלה `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `image`) VALUES
(1, 'Brake system', 'brake.jpg'),
(2, 'Filters', 'filters.jpg'),
(3, 'Suspension', 'suspension.jpg'),
(4, 'Steering', 'steering.jpg'),
(5, 'Wipers and washers', 'wipers.jpg'),
(6, 'Engine parts', 'engine.jpg'),
(7, 'Fuel system', 'fuel.jpg'),
(8, 'Exhaust system', 'exhaust.jpg'),
(9, 'Electric system', 'electric.jpg'),
(10, 'Engine cooling', 'cooling.jpg'),
(11, 'Heating and ventilation', 'heating.jpg'),
(12, 'Transmission and clutch', 'transmission.jpg'),
(13, 'Car body and interior', 'body.jpg'),
(14, 'Lighting', 'lighting.jpg');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `manufacturers`
--

CREATE TABLE `manufacturers` (
  `manufacturer_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- הוצאת מידע עבור טבלה `manufacturers`
--

INSERT INTO `manufacturers` (`manufacturer_id`, `name`, `image`) VALUES
(1, 'mercedesbenz', 'mercedesbenz.png'),
(2, 'BMW', 'bmw.png'),
(3, 'Skoda', 'skoda.png'),
(4, 'Seat', 'seat.png');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `order_readydate` datetime DEFAULT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `paypal_id` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Paid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- הוצאת מידע עבור טבלה `orders`
--

INSERT INTO `orders` (`order_id`, `order_date`, `order_readydate`, `total_price`, `user_id`, `paypal_id`, `status`) VALUES
(1, '2025-05-28 12:09:25', NULL, 90.00, 5, '04R97247L1227973N', 'Paid');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `orders_products`
--

CREATE TABLE `orders_products` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- הוצאת מידע עבור טבלה `orders_products`
--

INSERT INTO `orders_products` (`order_id`, `product_id`, `quantity`) VALUES
(1, 27, 1);

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `model_year` year(4) DEFAULT NULL,
  `model_class` varchar(100) DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock_quantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- הוצאת מידע עבור טבלה `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `price`, `category_id`, `subcategory_id`, `model_year`, `model_class`, `manufacturer_id`, `supplier_id`, `image`, `stock_quantity`) VALUES
(7, 'TurboCharger', 'mercedes m642 turbo', 500.00, 6, 19, '2020', '2018', 1, 1, '1746896109768-206075623.jpg', 20),
(8, 'Coils ', 'mercedes m272', 140.00, 9, 29, '2007', 'E-Class', 1, 6, '1746896369711-884800112.jpg', 110),
(9, 'Right HeadLamp', 'Skoda Superb', 200.00, 14, 43, '2019', 'Superb 4X4', 3, 6, '1746896889322-559464019.jpg', 50),
(10, 'Rear Light', 'Skoda Octavia 1.5 rear light', 80.00, 14, 42, '2017', 'Octavia', 3, 8, '1746897106870-179849299.jpg', 120),
(11, 'Front Grill', 'Skoda Octavia Front Grill', 140.00, 13, 39, '2018', 'Octavia', 3, 5, '1746897260790-542921087.jpg', 40),
(12, 'Right HeadLamp', 'Seat Leon HeadLamp R', 200.00, 14, 43, '2025', 'Leon', 4, 1, '1746897390134-621026185.jpg', 50),
(13, 'Rear Lights', 'Seat Leon RearLight 2X', 170.00, 14, 42, '2025', 'Leon', 4, 1, '1746897496986-777043560.jpg', 15),
(14, 'TurboCharger', 'Seat Leon Turbo K03s', 300.00, 6, 19, '2022', 'Leon', 4, 4, '1746897642737-281685598.jpg', 70),
(15, 'Left HeadLamp', 'BMW Headlamp', 130.00, 14, 43, '2021', 'M4', 2, 2, '1746897949182-994872622.jpg', 30),
(16, 'Mirror', 'Skoda Superb', 270.00, 13, 39, '2019', 'Superb 4X4', 3, 3, '1746898125430-856059602.jpg', 90),
(18, 'Rear Light', 'BMW rearlight', 150.00, 14, 42, '2022', 'M3 C5', 2, 2, '1746898680586-842005286.jpg', 60),
(19, 'Fog Lamps', 'mercedes w212 fog lamps', 170.00, 14, 44, '2012', 'E-Class', 1, 6, '1746898863843-422944420.jpg', 140),
(20, 'Front bumper', 'mercedes w222 front bumper', 900.00, 13, 40, '2024', 'S-Class', 1, 7, '1746899073371-54613913.jpg', 40),
(22, 'Exhaust Sensor', 'BMW O2 Sensor', 200.00, 8, 25, '2021', '330i', 2, 4, '1746966832775-199031389.jpg', 70),
(23, 'HeadLight ', 'mercedes w211 headlight ', 200.00, 14, 43, '2018', 'E-Class', 1, 6, '1746967720315-160909620.jpg', 130),
(24, 'EGR tranducer', 'BMW X6 EGR', 40.00, 8, 26, '2019', 'X6', 2, 1, '1747058089579-egrtranducer.jpg', 15),
(25, 'Exhaust Manifold gaskets', 'BMW 325i exhaust gaskets', 200.00, 8, 24, '2015', '325i', 2, 4, '1747058189330-exgasket.jpg', 40),
(26, 'Exhaust Sensor', 'BMW O2 exhaust sensor', 150.00, 8, 25, '2024', '318i', 2, 8, '1747058364670-o2sens.jpg', 60),
(27, 'Left HeadLamp', 'BMW 530i L HeadLamp', 90.00, 14, 43, '2017', '530i', 2, 6, '1747058534165-530ihe.jpg', 55),
(28, 'Rear Light', 'BMW X6 Rear tail light', 160.00, 14, 42, '2023', 'X6', 2, 6, '1747058636637-x6tail.jpg', 60),
(29, 'Right Rear Light', 'BMW X5 taillight', 300.00, 14, 42, '2024', 'X5', 2, 6, '1747058780988-bmwtail.jpg', 88),
(30, 'Left Headlamp', 'BMW M5 e60 headlamp led', 200.00, 14, 43, '2006', 'M5 E60', 2, 6, '1747059113491-Screenshot_14.jpg', 30),
(31, 'DPF', 'Diesel Particulate Filter for bmw x6', 600.00, 8, 26, '2020', 'X6', 2, 4, '1747059260616-x62020dpf.jpg', 25),
(32, 'Catalytic Convertor', 'BMW i330 catalytic Convertor', 350.00, 8, 26, '2018', '330i', 2, 1, '1747059410885-cata330.jpg', 70),
(34, 'Front Bumper', 'mercedes w212 front bumper', 250.00, 13, 40, '2012', 'E-Class', 1, 5, '1747059607478-w212fr.jpg', 60),
(35, 'Rear bumper', 'mercedes w212 rear bumper', 230.00, 13, 40, '2011', 'E-Class', 1, 5, '1747059731026-Screenshot_15.jpg', 80),
(36, 'Rear Bumper', 'mercedes w213 rear bumper', 400.00, 13, 40, '2020', 'E-Class', 1, 7, '1747059819888-w213re.jpg', 80),
(37, 'Front Bumper', 'mercedes w213 front bumper', 500.00, 13, 40, '2021', 'E-Class', 1, 7, '1747059916549-fr213.jpg', 70),
(38, 'Rear Bumper', 'mercedes w222 rear bumper', 600.00, 13, 40, '2023', 'S-Class', 1, 4, '1747060182385-w220re.jpg', 93),
(39, 'Coil', 'mercedes m270 cla/a/gla ignition coil', 70.00, 9, 29, '2017', 'CLA-Class', 1, 1, '1747061830390-m270.jpg', 100),
(40, 'Coil', 'mercedes m271 CGI ignition coil', 80.00, 9, 29, '2012', 'E-Class', 1, 1, '1747061909003-m271.jpg', 120),
(41, 'coil', 'mercedes m276 ignition coil  E/C/GLE 350 petrol', 110.00, 9, 29, '2016', 'E-Class', 1, 1, '1747061998937-m276.jpg', 130),
(42, 'coil', 'mercedes m112 ignition coil E/C/ML 320 / 240', 70.00, 9, 29, '2005', 'E-Class', 1, 1, '1747062097164-m112.jpg', 130),
(43, 'coil', 'mercedes m274 ignition coil', 100.00, 9, 29, '2016', 'C-Class', 1, 1, '1747062186789-m274.jpg', 150),
(44, 'TurboCharger', 'mercedes m270 turbocharger', 550.00, 6, 19, '2018', 'CLA-Class', 1, 7, '1747062292935-m27ot.jpg', 30),
(45, 'TurboCharger', 'mercedes m271 engine turbocharger ', 220.00, 6, 19, '2013', 'E-Class', 1, 7, '1747062377263-m271tt.jpg', 50),
(46, 'Throttle Valve Body', 'mercedes m272 throttle valve body', 140.00, 6, 18, '2012', 'E-Class', 1, 8, '1747062535745-th272.jpg', 42),
(47, 'Throttle Valve Body', 'mercedes m270 throttle valve body', 230.00, 6, 18, '2019', 'A-Class', 1, 8, '1747062640867-ttm270.jpg', 66),
(48, 'Engine Mount', 'mercedes m272 / m112 engine mount', 100.00, 6, 20, '2011', 'E-Class', 1, 8, '1747062807146-eng272.jpg', 110),
(49, 'Rear L Light', 'mercedes w211 rear left light', 90.00, 14, 42, '2009', 'E-Class', 1, 6, '1747063001235-t211.jpg', 200),
(50, 'Rear Lights', 'mercedes w212 Left rear lights ', 280.00, 14, 42, '2014', 'E-Class', 1, 6, '1747063114490-w212pai.jpg', 50),
(51, 'Rear trunk light', 'mercedes w211 trunk brake light', 95.00, 14, 42, '2008', 'E-Class', 1, 6, '1747063208982-trun211.jpg', 80),
(52, 'Right HeadLamp', 'mercedes w212 headlamp right', 220.00, 14, 43, '2012', 'E-Class', 1, 5, '1747063330388-w21h.jpg', 70),
(53, 'Fuel Pump', 'mercedes w211 fuel pump', 230.00, 7, 22, '2009', 'E-Class', 1, 5, '1747064125973-w2111f.jpg', 60),
(54, 'Fuel Pump', 'mercedes w212 fuel pump ', 240.00, 7, 22, '2013', 'E-Class', 1, 5, '1747064235258-w212fp.jpg', 77),
(55, 'Fuel Pump', 'mercedes w213 fuel pump', 300.00, 7, 22, '2020', 'E-Class', 1, 1, '1747064432506-w213.jpg', 30),
(56, 'Fuel Injectors', 'mercedes m272  6Xfuel injectors', 160.00, 7, 21, '2013', 'E-Class', 1, 3, '1747064672128-m272inj.jpg', 90),
(57, 'Front Bumper', 'mercedes w205 C-class Front bumper', 700.00, 13, 40, '2018', 'C-Class', 1, 3, '1747343335156-c205.jpg', 60),
(58, 'Washer blades', 'mercedes w211 waher blades', 50.00, 5, 14, '2009', 'E-Class', 1, 1, '1747402230779-w2.jpg', 90),
(59, 'Wahers pump', 'mercedes w211 wahers pump', 70.00, 5, 16, '2009', 'E-Class', 1, 4, '1747402353800-w211w.jpg', 50),
(60, 'grill', 'skoda octavia 2022 grill', 110.00, 13, 39, '2022', 'Octavia', 3, 6, '1747402468818-Screenshot_1.jpg', 150),
(61, 'TCU', 'skoda superb DSG 7 speed tcu', 800.00, 12, 36, '2019', 'Superb 4X4', 3, 1, '1747402625536-Screenshot_2.jpg', 80),
(62, 'drive shaft ', 'skoda superb 2020(L) drive shaft', 70.00, 12, 38, '2020', 'Superb 4X4', 3, 7, '1747402816689-Screenshot_3.jpg', 90),
(63, 'Water pump', 'skoda superb 2.0TSI  water pump', 120.00, 10, 30, '2021', 'Superb 4X4', 3, 8, '1747402968662-Screenshot_5.jpg', 135),
(64, 'license plate holders', 'skoda superb 2021 pair license holder', 120.00, 13, 41, '2021', 'Superb 4X4', 3, 5, '1747403393029-sk.jpg', 200),
(65, 'rear trunk light', 'skoda superb trunk light 2022', 200.00, 14, 42, '2022', 'Superb 4X4', 3, 4, '1747403526171-Screenshot_6.jpg', 70),
(66, 'exhaust end back part', 'Skoda Superb exhaust back part', 300.00, 8, 26, '2023', 'Superb 4X4', 3, 1, '1747403640403-Screenshot_7.jpg', 150),
(67, 'shock absorbers', 'skoda superb 2018 shock absorbers', 190.00, 3, 8, '2018', 'Superb 4X4', 3, 7, '1747403776218-Screenshot_8.jpg', 250),
(68, 'front brake discs', 'skoda Superb 4X4 front brake discs', 250.00, 1, 1, '2020', 'Superb 4X4', 3, 1, '1747403892852-Screenshot_9.jpg', 330),
(69, 'front brakes', 'Skoda Superb front brakes', 270.00, 1, 2, '2018', 'Superb 4X4', 3, 6, '1747403982997-Screenshot_10.jpg', 400),
(70, 'front brake discs', 'skoda octavia 2018 brake discs', 150.00, 1, 1, '2018', 'Octavia', 3, 8, '1747404148725-Screenshot_11.jpg', 240),
(71, 'AC compressor', 'skoda octavia 1.5 tsi ac compressor', 220.00, 11, 34, '2017', 'Octavia', 3, 3, '1747404825499-sacc.jpg', 250),
(72, 'ignition coils', 'skoda 1.5 octavia ignition coils', 300.00, 9, 29, '2018', 'Octavia', 3, 1, '1747404969114-Screenshot_12.jpg', 170),
(73, 'fuel pump', 'skoda octavia 1.5 fuel pump 2019', 400.00, 7, 22, '2019', 'Octavia', 3, 3, '1747405092995-Screenshot_13.jpg', 130),
(74, 'steering arms', 'skoda superb steering arms 2X', 70.00, 4, 12, '2020', 'Superb 4X4', 3, 7, '1747405261319-Screenshot_14.jpg', 190),
(75, 'oil filter', 'skoda octavia oil filter 1.5tsi', 30.00, 2, 5, '2018', 'Octavia', 3, 3, '1747405402324-Screenshot_15.jpg', 600),
(76, 'air filter', 'skoda octavia 1.5tsi air filter', 50.00, 2, 6, '2019', 'Octavia', 3, 5, '1747405484711-Screenshot_16.jpg', 700),
(77, 'cabin air filter', 'skoda octavia 1.5tsi cabin air filter', 90.00, 2, 7, '2020', 'Octavia', 3, 1, '1747405569067-Screenshot_17.jpg', 500),
(78, 'wiper blades', 'skoda octavia vrs 2.0  wiper blades', 140.00, 5, 14, '2022', 'Octavia', 3, 1, '1747405843524-Screenshot_18.jpg', 310),
(79, 'Maxton Design ', 'Maxton Design Body kit for Skoda VRS 2019', 890.00, 13, 40, '2019', 'VRS Octavia', 3, 8, '1748429873624-maxtonbodykit.jpg', 50);

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `subcategories`
--

CREATE TABLE `subcategories` (
  `subcategory_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- הוצאת מידע עבור טבלה `subcategories`
--

INSERT INTO `subcategories` (`subcategory_id`, `name`, `category_id`) VALUES
(1, 'brake discs', 1),
(2, 'brake pads', 1),
(3, 'brake hoses', 1),
(4, 'brake shoes', 1),
(5, 'oil filters', 2),
(6, 'air filters', 2),
(7, 'cabin air filters', 2),
(8, 'shock absorbers', 3),
(9, 'wheel bearings', 3),
(10, 'air springs', 3),
(11, 'tie rods', 4),
(12, 'steering arms', 4),
(13, 'power steering tanks', 4),
(14, 'wiper blades', 5),
(15, 'wiper motors', 5),
(16, 'windscreen washer pumps', 5),
(17, 'timing chain sets', 6),
(18, 'throttle bodies', 6),
(19, 'egr', 6),
(20, 'engine mountings', 6),
(21, 'injector nozzles', 7),
(22, 'fuel pumps', 7),
(23, 'secondary air injection pumps', 7),
(24, 'exhaust gaskets', 8),
(25, 'lambda sensors', 8),
(26, 'Diesel Particulate Filter', 8),
(27, 'alternators', 9),
(28, 'starters', 9),
(29, 'ignition coils', 9),
(30, 'water pumps', 10),
(31, 'radiator fans', 10),
(32, 'intercoolers', 10),
(33, 'cooling radiators', 10),
(34, 'ac compressors', 11),
(35, 'interior blower motors', 11),
(36, 'propshaft center bearings', 12),
(37, 'transmission mounting', 12),
(38, 'drive shafts', 12),
(39, 'front grills', 13),
(40, 'bumper parts', 13),
(41, 'license plate holders', 13),
(42, 'tail lights', 14),
(43, 'headlights', 14),
(44, 'front fog lights', 14);

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- הוצאת מידע עבור טבלה `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `supplier_name`, `email`, `phone`) VALUES
(1, 'Bosch Auto Parts', 'contact@bosch.de', '+49 711 400 4090'),
(2, 'ZF Friedrichshafen AG', 'support@zf.com', '+49 7541 770'),
(3, 'Mahle GmbH', 'info@mahle.com', '+49 711 501-0'),
(4, 'Schaeffler Group', 'service@schaeffler.com', '+49 9132 82-0'),
(5, 'Continental Automotive', 'sales@continental.com', '+49 511 938-01'),
(6, 'Hella GmbH & Co. KGaA', 'info@hella.com', '+49 2941 38-0'),
(7, 'Bilstein Group', 'inquiry@bilstein.de', '+49 2339 911-0'),
(8, 'Meyle AG', 'customerservice@meyle.com', '+49 40 67506-0');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `role` varchar(50) DEFAULT 'customer',
  `created_at` datetime DEFAULT current_timestamp(),
  `profile_picture` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- הוצאת מידע עבור טבלה `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `phone`, `address`, `role`, `created_at`, `profile_picture`) VALUES
(1, 'Yazan G W', 'yazan644@gmail.com', '$2b$10$d9LQRlu8mwTRd9GOe5nN4ect5px0AS67bDqgVNgaCzvw2ubrQxCZG', '0501234567', 'Nazareth', 'admin', '2025-05-06 18:19:15', '1750892876608-blackw2112.jpg'),
(2, 'Saed', 'saed999@gmail.com', '$2b$10$9bLGLwC/QHpTWZYjyvn64./1GRWcSttM2MyrqQ7f1xuD9Wkg7aKP2', '0507654321', 'Hebron', 'admin', '2025-05-06 18:19:15', 'saed.jpg'),
(5, 'Ameer Haloumi', 'ameer@gmail.com', '$2b$10$4Ncx3v0aU.XDz0pAFSPZLOrR2q9ecFdgTn/Sl0oK2L496pCD53FYi', '0523391220', 'Nazareth sfafra prince barbershop', 'customer', '2025-05-12 15:41:04', '1748426190420-PrinceAmeer.jpg'),
(6, 'Majd Alaraj', 'majd@g.com', '$2b$10$JXqqYqBKSdnrMeqQDtPEHOS80mGK2YASR6WYBNZsu0F47YfslS8z.', '0530530547', 'nazareth,st1999', 'customer', '2025-05-15 19:33:13', '1747326793433-mjd.jpg'),
(7, 'Yazeed Wahbih', 'yazeed@gmail.com', '$2b$10$q407iV/HAK8gQV4BSaujx.krdaFgjzn24M15MDfVK3QDh1G/cQnhq', '0525964321', 'Nazareth ', 'customer', '2025-05-16 03:21:17', '1747354877299-yazeedd.jpg');

--
-- Indexes for dumped tables
--

--
-- אינדקסים לטבלה `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `fk_cart_user` (`user_id`),
  ADD KEY `fk_cart_product` (`product_id`);

--
-- אינדקסים לטבלה `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- אינדקסים לטבלה `manufacturers`
--
ALTER TABLE `manufacturers`
  ADD PRIMARY KEY (`manufacturer_id`);

--
-- אינדקסים לטבלה `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `fk_orders_user` (`user_id`);

--
-- אינדקסים לטבלה `orders_products`
--
ALTER TABLE `orders_products`
  ADD PRIMARY KEY (`order_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- אינדקסים לטבלה `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `fk_product_category` (`category_id`),
  ADD KEY `fk_product_subcategory` (`subcategory_id`),
  ADD KEY `fk_product_manufacturer` (`manufacturer_id`),
  ADD KEY `fk_product_supplier` (`supplier_id`);

--
-- אינדקסים לטבלה `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`subcategory_id`),
  ADD KEY `fk_subcategories_category` (`category_id`);

--
-- אינדקסים לטבלה `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- אינדקסים לטבלה `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `manufacturers`
--
ALTER TABLE `manufacturers`
  MODIFY `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `subcategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- הגבלות לטבלאות שהוצאו
--

--
-- הגבלות לטבלה `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_cart_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- הגבלות לטבלה `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- הגבלות לטבלה `orders_products`
--
ALTER TABLE `orders_products`
  ADD CONSTRAINT `fk_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_products_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- הגבלות לטבלה `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_manufacturer` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturers` (`manufacturer_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_product_manufacturer` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturers` (`manufacturer_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_product_subcategory` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`subcategory_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_product_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- הגבלות לטבלה `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `fk_subcategories_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
