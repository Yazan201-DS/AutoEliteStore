import express from "express";
import { getPool } from "./db.js";

const router = express.Router();

//Overview stats for Admin Dashboard
router.get("/overview", async (req, res) => {
  const user = req.session?.user;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const pool = await getPool();
  const conn = await pool.getConnection();

  try {
    const [[{ totalUsers }]] = await conn.query(`
      SELECT COUNT(*) AS totalUsers FROM users WHERE role = 'customer'
    `);

    const [[{ totalOrders }]] = await conn.query(`
      SELECT COUNT(*) AS totalOrders FROM orders
    `);

    const [[{ totalRevenue }]] = await conn.query(`
      SELECT IFNULL(SUM(total_price), 0) AS totalRevenue FROM orders
    `);

    const [[{ totalProductsSold }]] = await conn.query(`
      SELECT IFNULL(SUM(quantity), 0) AS totalProductsSold FROM orders_products
    `);

    const [[{ totalProductsInStore }]] = await conn.query(`
      SELECT COUNT(*) AS totalProductsInStore FROM products
    `);

    const [[{ totalStockQuantity }]] = await conn.query(`
      SELECT IFNULL(SUM(stock_quantity), 0) AS totalStockQuantity FROM products
    `);

    const [[{ outOfStockCount }]] = await conn.query(`
      SELECT COUNT(*) AS outOfStockCount FROM products WHERE stock_quantity = 0
    `);

    res.json({
      totalUsers,
      totalOrders,
      totalRevenue,
      totalProductsSold,
      totalProductsInStore,
      totalStockQuantity,
      outOfStockCount
    });
  } catch (err) {
    console.error("Overview stats error:", err);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    conn.release();
  }
});

//Top Selling Products
router.get("/top-products", async (req, res) => {
  const user = req.session?.user;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const pool = await getPool();
  const conn = await pool.getConnection();

  try {
    const [results] = await conn.query(`
      SELECT p.name, SUM(op.quantity) AS quantity
      FROM orders_products op
      JOIN products p ON op.product_id = p.product_id
      GROUP BY op.product_id
      ORDER BY quantity DESC
      LIMIT 5
    `);
    res.json(results);
  } catch (err) {
    console.error("Top products error:", err);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    conn.release();
  }
});

//Recent Orders
router.get("/recent-orders", async (req, res) => {
  const user = req.session?.user;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const pool = await getPool();
  const conn = await pool.getConnection();

  try {
    const [orders] = await conn.query(`
      SELECT o.order_id, o.order_date, o.total_price, u.name
      FROM orders o
      JOIN users u ON o.user_id = u.user_id
      ORDER BY o.order_date DESC
      LIMIT 5
    `);
    res.json(orders);
  } catch (err) {
    console.error("Recent orders error:", err);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    conn.release();
  }
});

//Low Stock Products (< 50)
router.get("/low-stock-products", async (req, res) => {
  const user = req.session?.user;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const pool = await getPool();
  const conn = await pool.getConnection();

  try {
    const [rows] = await conn.query(`
      SELECT product_id, name, stock_quantity
      FROM products
      WHERE stock_quantity < 50
      ORDER BY stock_quantity ASC
    `);
    res.json(rows);
  } catch (err) {
    console.error("Low stock query failed:", err);
    res.status(500).json({ error: "Failed to fetch low stock products" });
  } finally {
    conn.release();
  }
});

//Update Stock Quantity
router.put("/products/:id/quantity", async (req, res) => {
  const { quantity } = req.body;
  const productId = req.params.id;

  const user = req.session?.user;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const pool = await getPool();
  const conn = await pool.getConnection();

  try {
    await conn.query(
      "UPDATE products SET stock_quantity = ? WHERE product_id = ?",
      [quantity, productId]
    );
    res.json({ success: true });
  } catch (err) {
    console.error("Quantity update error:", err);
    res.status(500).json({ error: "Failed to update quantity" });
  } finally {
    conn.release();
  }
});

export default router;
