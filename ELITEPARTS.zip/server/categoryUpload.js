//categoryUpload.js
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { dirname } from "path";

//ES module __dirname workaround
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

//Correct path to /public/images/categories (ROOT-level, not inside server)
const categoriesPath = path.resolve(__dirname, "../../public/images/categories");

//Ensure the directory exists
if (!fs.existsSync(categoriesPath)) {
  fs.mkdirSync(categoriesPath, { recursive: true });
  console.log("Created missing folder:", categoriesPath);
}

//Multer storage config
const categoryStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, categoriesPath);
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); // Optional: use unique naming if needed
  },
});

export const uploadCategoryImage = multer({ storage: categoryStorage });
