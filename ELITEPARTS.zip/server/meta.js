//meta
import express from 'express';
import { getPool } from './db.js';

const router = express.Router();

//GET /api/categories → { id, name }
router.get('/categories', async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT category_id AS category_id, name FROM categories');
    res.json(rows);
  } catch (err) {
    console.error("Fetch categories error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

//GET /api/subcategories → { id, name }
router.get('/subcategories', async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT subcategory_id AS subcategory_id, name FROM subcategories');
    res.json(rows);
  } catch (err) {
    console.error("Fetch subcategories error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

//GET /api/manufacturers → { id, name }
router.get('/manufacturers', async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT manufacturer_id AS manufacturer_id, name FROM manufacturers');
    res.json(rows);
  } catch (err) {
    console.error("Fetch manufacturers error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

//GET /api/suppliers → { id, supplier_name }
router.get('/suppliers', async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT supplier_id AS id, supplier_name AS name FROM suppliers');
    res.json(rows);
  } catch (err) {
    console.error("Fetch suppliers error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});


//GET /api/categories/:id/subcategories → subcategories by category
router.get('/categories/:id/subcategories', async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      'SELECT subcategory_id AS subcategory_id, name FROM subcategories WHERE category_id = ?',
      [id]
    );
    res.json(rows);
  } catch (err) {
    console.error('Subcategory fetch error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});


export default router;
