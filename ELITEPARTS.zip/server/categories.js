import express from "express";
import { uploadCategoryImage } from "./categoryUpload.js";
import { fileURLToPath } from "url";
import { dirname } from "path";
import { getPool } from "./db.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const router = express.Router();

//GET all categories
router.get("/", async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query("SELECT category_id, name, image FROM categories");
    res.json(rows);
  } catch (err) {
    console.error("Fetch categories error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

//GET subcategories for a given category_id
router.get("/:id/subcategories", async (req, res) => {
  const { id } = req.params;

  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      "SELECT subcategory_id, name FROM subcategories WHERE category_id = ?",
      [id]
    );
    res.json(rows);
  } catch (err) {
    console.error("Subcategory fetch error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

//POST: Add new category
router.post("/", uploadCategoryImage.single("image"), async (req, res) => {
  const { name } = req.body;
  const image = req.file?.filename;

  if (!name || !image) {
    return res.status(400).json({ message: "Name and image are required" });
  }

  try {
    const pool = await getPool();
    await pool.query("INSERT INTO categories (name, image) VALUES (?, ?)", [name, image]);
    res.status(201).json({ message: "Category added" });
  } catch (err) {
    console.error("Insert category error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

//DELETE: Remove category
router.delete("/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const pool = await getPool();
    await pool.query("DELETE FROM categories WHERE category_id = ?", [id]);
    res.json({ message: "Category deleted" });
  } catch (err) {
    console.error("Delete category error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

//PUT: Update category
router.put("/:id", uploadCategoryImage.single("image"), async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  const image = req.file?.filename || null;

  try {
    const pool = await getPool();

    const updates = [];
    const values = [];

    if (name) {
      updates.push("name = ?");
      values.push(name);
    }

    if (image) {
      updates.push("image = ?");
      values.push(image);
    }

    if (updates.length === 0) {
      return res.status(400).json({ message: "Nothing to update" });
    }

    const query = `UPDATE categories SET ${updates.join(", ")} WHERE category_id = ?`;
    values.push(id);

    await pool.query(query, values);
    res.json({ message: "Category updated successfully" });
  } catch (err) {
    console.error("Update error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
