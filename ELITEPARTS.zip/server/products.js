// server/products.js
import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { getPool } from './db.js';
import upload from './upload.js'; //Shared uploader

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

//GET grouped by brand/category
router.get('/products/grouped-by-brand-category', async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query(`
      SELECT p.product_id, p.name, p.price, p.image, p.description, p.model_year, p.model_class,
             sc.name AS subcategory_name, c.name AS categoryName, m.name AS brandName
      FROM products p
      LEFT JOIN subcategories sc ON p.subcategory_id = sc.subcategory_id
      JOIN categories c ON p.category_id = c.category_id
      JOIN manufacturers m ON p.manufacturer_id = m.manufacturer_id
      ORDER BY m.name, c.name
    `);

    const result = {};
    for (const row of rows) {
      if (!result[row.brandName]) result[row.brandName] = {};
      if (!result[row.brandName][row.categoryName]) result[row.brandName][row.categoryName] = [];
      result[row.brandName][row.categoryName].push({
        product_id: row.product_id,
        name: row.name,
        price: row.price,
        image: row.image,
        description: row.description,
        model_year: row.model_year,
        model_class: row.model_class,
        subcategory_name: row.subcategory_name
      });
    }

    const formatted = Object.entries(result).map(([brandName, categories]) => ({
      brandName,
      categories: Object.entries(categories).map(([categoryName, products]) => ({
        categoryName,
        products,
      })),
    }));

    res.json(formatted);
  } catch (err) {
    console.error("Grouped fetch error:", err.message);
    res.status(500).json({ message: "Server error" });
  }
});

//GET all products
router.get('/products', async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query(`
  SELECT products.*, 
         categories.name AS category_name, 
         subcategories.name AS subcategory_name, 
         manufacturers.name AS manufacturer_name,
         suppliers.supplier_name AS supplier_name
  FROM products
  LEFT JOIN categories ON products.category_id = categories.category_id
  LEFT JOIN subcategories ON products.subcategory_id = subcategories.subcategory_id
  LEFT JOIN manufacturers ON products.manufacturer_id = manufacturers.manufacturer_id
  LEFT JOIN suppliers ON products.supplier_id = suppliers.supplier_id
`);

    res.json(rows);
  } catch (err) {
    console.error('Fetch products error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

//POST: Add new product
router.post('/products', upload.single('image'), async (req, res) => {
  const {
    name, description, price, category_id, subcategory_id,
    model_year, model_class, manufacturer_id, supplier_id, stock_quantity
  } = req.body;

  const image = req.file?.filename;

  if (!name || !description || !price || !category_id || !manufacturer_id || !supplier_id || !stock_quantity || !image) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  try {
    const pool = await getPool();
    await pool.query(`
      INSERT INTO products 
      (name, description, price, category_id, subcategory_id, model_year, model_class, manufacturer_id, supplier_id, stock_quantity, image)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [name, description, price, category_id, subcategory_id || null, model_year || null, model_class || null,
       manufacturer_id, supplier_id, stock_quantity, image]
    );

    res.status(201).json({ message: 'Product added successfully' });
  } catch (err) {
    console.error('Insert product error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

//DELETE product + image
router.delete('/products/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT image FROM products WHERE product_id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Product not found' });

    const imageFile = rows[0].image;
    const imagePath = path.join(__dirname, '..', 'public', 'images', 'products', imageFile);

    await pool.query('DELETE FROM products WHERE product_id = ?', [id]);

    if (fs.existsSync(imagePath)) fs.unlinkSync(imagePath);

    res.json({ message: 'Product and image deleted successfully' });
  } catch (err) {
    console.error('Delete error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

//PUT: Update product
router.put('/products/:id', upload.single('image'), async (req, res) => {
  const { id } = req.params;
  const {
    name, description, price, category_id, subcategory_id,
    model_year, model_class, manufacturer_id, supplier_id, stock_quantity
  } = req.body;

  const newImage = req.file?.filename;

  try {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT * FROM products WHERE product_id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Product not found' });

    const oldImage = rows[0].image;
    const updatedImage = newImage || oldImage;

    await pool.query(`
      UPDATE products SET 
        name = ?, description = ?, price = ?, category_id = ?, subcategory_id = ?, 
        model_year = ?, model_class = ?, manufacturer_id = ?, supplier_id = ?, 
        stock_quantity = ?, image = ?
      WHERE product_id = ?`,
      [name, description, price, category_id, subcategory_id || null, model_year || null,
       model_class || null, manufacturer_id, supplier_id, stock_quantity, updatedImage, id]
    );

    if (newImage && oldImage) {
      const oldImagePath = path.join(__dirname, '..', 'public', 'images', 'products', oldImage);
      if (fs.existsSync(oldImagePath)) fs.unlinkSync(oldImagePath);
    }

    res.json({ message: 'Product updated successfully' });
  } catch (err) {
    console.error('Update error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get("/products/search", async (req, res) => {
  const term = req.query.term;
  if (!term) return res.json([]);

  try {
    const pool = await getPool();
    const [results] = await pool.query(
      `SELECT product_id, name, price, image, description, model_year, model_class, stock_quantity
       FROM products
       WHERE name LIKE ? OR description LIKE ? OR model_class LIKE ?
       LIMIT 10`,
      [`%${term}%`, `%${term}%`, `%${term}%`]
    );
    res.json(results);
  } catch (err) {
    console.error("Search error:", err);
    res.status(500).json({ message: "Search failed" });
  }
});




export default router;
