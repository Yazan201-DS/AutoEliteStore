//auth.js
import express from 'express';
import bcrypt from 'bcrypt';
import { getPool } from './db.js';

const router = express.Router();

//Login Route
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  console.log("Login request:", email);

  try {
    const pool = await getPool();
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);

    if (rows.length === 0) {
      console.log("No user with that email");
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const user = rows[0];
    const match = await bcrypt.compare(password, user.password);

    if (!match) {
      console.log("Password does not match");
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    //Save user to session (excluding password)
    req.session.user = {
  user_id: user.user_id, 
  username: user.name,
  email: user.email,
  role: user.role,
  phone: user.phone,               
  address: user.address,
  profile_picture: user.profile_picture
};


    console.log("Session user set:", req.session.user);

    res.json({ message: 'Login successful', user: req.session.user });

  } catch (err) {
    console.error("Login error:", err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

//Logout Route
router.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error("Logout error:", err.message);
      return res.status(500).json({ message: 'Logout failed' });
    }
    res.clearCookie('connect.sid');
    res.json({ message: 'Logged out' });
  });
});

export default router;
