//users.js
import express from "express";
import fs from "fs";
import path from "path";
import bcrypt from "bcrypt";
import { getPool } from "./db.js";
import upload from "./upload.js"; //Shared Multer config

const router = express.Router();

//PUT /users/:id/profile_picture → update user's profile image
router.put("/users/:id/profile_picture", upload.single("profile_picture"), async (req, res) => {
  const userId = req.params.id;
  const filename = req.file?.filename;

  if (!filename) {
    return res.status(400).json({ message: "No file uploaded" });
  }

  try {
    const pool = await getPool();

    //Get current profile picture
    const [[user]] = await pool.query("SELECT profile_picture FROM users WHERE user_id = ?", [userId]);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    //Delete old profile picture if it exists
    const oldPicture = user.profile_picture;
    const oldPath = path.resolve("public", "images", "profiles", oldPicture);

    if (oldPicture && fs.existsSync(oldPath)) {
      fs.unlinkSync(oldPath);
    }

    //Update new profile picture
    await pool.query("UPDATE users SET profile_picture = ? WHERE user_id = ?", [filename, userId]);

    res.json({ message: "Profile picture updated successfully", filename });
  } catch (err) {
    console.error("Profile upload error:", err);
    res.status(500).json({ message: "Internal server error" });
  }
});

//PUT /users/:id → update name, phone, address
router.put("/users/:id", async (req, res) => {
  const userId = req.params.id;
  const { name, phone, address } = req.body;

  if (!name || !phone || !address) {
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    const pool = await getPool();
    const [result] = await pool.query(
      "UPDATE users SET name = ?, phone = ?, address = ? WHERE user_id = ?",
      [name, phone, address, userId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ message: "User updated successfully" });
  } catch (err) {
    console.error("User update error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

//PUT /users/:id/password → change password securely
router.put("/users/:id/password", async (req, res) => {
  const userId = req.params.id;
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    return res.status(400).json({ message: "Both current and new passwords are required" });
  }

  try {
    const pool = await getPool();

    //Fetch user's current password hash
    const [[user]] = await pool.query("SELECT password FROM users WHERE user_id = ?", [userId]);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    //Compare current password
    const match = await bcrypt.compare(currentPassword, user.password);
    if (!match) {
      return res.status(401).json({ message: "Incorrect current password" });
    }

    //Hash and store new password
    const hashedNew = await bcrypt.hash(newPassword, 10);
    await pool.query("UPDATE users SET password = ? WHERE user_id = ?", [hashedNew, userId]);

    res.json({ message: "Password updated successfully" });
  } catch (err) {
    console.error("Password update error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

//GET /customers → get all users with role 'customer'
router.get("/customers", async (req, res) => {
  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      "SELECT user_id, name, email, phone, address, profile_picture FROM users WHERE role = 'customer'"
    );
    res.json(rows);
  } catch (err) {
    console.error("Fetch customers error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

//GET /me → get logged-in user from session
router.get("/me", (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ message: "Not logged in" });
  }

  res.json({ user: req.session.user });
});

export default router;
