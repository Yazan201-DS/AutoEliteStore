// server/server.js
import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import session from 'express-session';
import { fileURLToPath } from 'url';
import { getPool } from './db.js';
import cartRouter from './cart.js';
import authRouter from './auth.js';
import signupRouter from './signup.js';
import productsRouter from './products.js';
import metaRouter from './meta.js';
import categoryRouter from './categories.js';
import manufacturerRoutes from './manufacturers.js';
import userRoutes from './users.js';
import statisticsRoutes from "./statistics.js";
import orderRoutes from './orders.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

//Middleware
app.use(cors({
  origin: 'http://localhost:5173', // or your frontend URL
  credentials: true               // IMPORTANT for sessions
}));
app.use(express.json());

//Sessions
app.use(
  session({
    secret: 'autoelite-session-secret', //Use strong secret in production
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 60 * 2, // 2 hours
      sameSite: 'lax',    // ← allow your React app to send it on POST/GET
      secure: false,
    },
  })
);

//Ensure image folders exist
const rootImagesPath = path.join(__dirname, '..', 'public', 'images');
const requiredFolders = ['products', 'categories', 'profiles'];

requiredFolders.forEach(folder => {
  const fullPath = path.join(rootImagesPath, folder);
  if (!fs.existsSync(fullPath)) fs.mkdirSync(fullPath, { recursive: true });
});

//Serve static images
app.use('/images', express.static(rootImagesPath));

//API Routes
app.use('/api', authRouter);
app.use('/api', signupRouter);
app.use('/api', productsRouter);
app.use('/api', metaRouter);
app.use('/api/categories', categoryRouter);
app.use('/api/manufacturers', manufacturerRoutes);
app.use('/api', userRoutes);
app.use('/api', cartRouter);
app.use('/api/orders', orderRoutes);
app.use("/api/statistics", statisticsRoutes);

//Test route
app.get('/api/test', (req, res) => {
  res.json({ message: 'Proxy works!' });
});

//Start server
app.listen(PORT, async () => {
  try {
    await getPool();
    console.log('Connected to MySQL database!');
  } catch (err) {
    console.error('Database connection failed:', err.message);
  }
  console.log(`Backend running at http://localhost:${PORT}`);
});
