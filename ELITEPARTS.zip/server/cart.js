import express from "express";
import { getPool } from "./db.js";

const router = express.Router();

//GET: Fetch cart items for the logged-in user
router.get("/cart", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Not logged in" });

  const userId = req.session.user.user_id;

  try {
    const pool = await getPool();
    const [rows] = await pool.query(`
      SELECT c.cart_id, c.quantity, p.product_id, p.name, p.price, p.image
      FROM cart c
      JOIN products p ON c.product_id = p.product_id
      WHERE c.user_id = ?
    `, [userId]);

    res.json(rows);
  } catch (err) {
    console.error("Fetch cart error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

//POST: Add item to cart
router.post("/cart", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Not logged in" });

  const userId = req.session.user.user_id;
  const { product_id, quantity } = req.body;

  if (!product_id || !quantity) {
    return res.status(400).json({ message: "Missing product or quantity" });
  }

  try {
    const pool = await getPool();

    const [[existing]] = await pool.query(
      "SELECT * FROM cart WHERE user_id = ? AND product_id = ?",
      [userId, product_id]
    );

    if (existing) {
      await pool.query(
        "UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?",
        [quantity, userId, product_id]
      );
    } else {
      await pool.query(
        "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)",
        [userId, product_id, quantity]
      );
    }

    res.status(201).json({ message: "Added to cart" });
  } catch (err) {
    console.error("Add to cart error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

//DELETE: Remove item from cart by product ID
router.delete("/cart/:product_id", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Not logged in" });

  const userId = req.session.user.user_id;
  const productId = req.params.product_id;

  try {
    const pool = await getPool();
    const [result] = await pool.query(
      "DELETE FROM cart WHERE user_id = ? AND product_id = ?",
      [userId, productId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Item not found in cart" });
    }

    res.json({ message: "Item removed from cart" });
  } catch (err) {
    console.error("Delete cart item error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

//PUT: Update quantity of item in cart
router.put("/cart", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Not logged in" });

  const userId = req.session.user.user_id;
  const { product_id, quantity } = req.body;

  if (!product_id || quantity == null) {
    return res.status(400).json({ message: "Missing product ID or quantity" });
  }

  if (quantity <= 0) {
    return res.status(400).json({ message: "Quantity must be greater than zero" });
  }

  try {
    const pool = await getPool();

    const [result] = await pool.query(
      "UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?",
      [quantity, userId, product_id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Item not found in cart" });
    }

    res.json({ message: "Cart item updated successfully" });
  } catch (err) {
    console.error("Update cart quantity error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

//NEW: DELETE all items from the user's cart
router.delete("/clear", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Not logged in" });

  const userId = req.session.user.user_id;

  try {
    const pool = await getPool();
    await pool.query("DELETE FROM cart WHERE user_id = ?", [userId]);
    res.json({ message: "Cart cleared successfully" });
  } catch (err) {
    console.error("Clear cart error:", err);
    res.status(500).json({ message: "Failed to clear cart" });
  }
});

export default router;
