// server/upload.js
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Base image directory
const baseImageDir = path.join(__dirname, '..', 'public', 'images');
const productsPath = path.join(baseImageDir, 'products');
const profilesPath = path.join(baseImageDir, 'profiles');

// Ensure folders exist
[productsPath, profilesPath].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// Multer storage config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const folder = file.fieldname === 'profile_picture' ? profilesPath : productsPath; //standardized
    cb(null, folder);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueName);
  }
});

const upload = multer({ storage });

export default upload;
