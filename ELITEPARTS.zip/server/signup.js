import express from 'express';
import bcrypt from 'bcrypt';
import { getPool } from './db.js';
import upload from './upload.js'; //shared upload handler

const router = express.Router();

//POST /signup → with profile picture
router.post('/signup', upload.single('profile_picture'), async (req, res) => {
  const { username, email, password, phone, address } = req.body;
  const profile_picture = req.file?.filename;

  if (!username || !email || !password || !phone || !address || !profile_picture) {
    return res.status(400).json({ message: 'All fields including profile picture are required' });
  }

  try {
    const pool = await getPool();

    //Check if email already exists
    const [existing] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    //Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    //Insert new user with profile picture and role 'customer'
    const [result] = await pool.query(
      `INSERT INTO users (name, email, password, phone, address, profile_picture, role)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [username, email, hashedPassword, phone, address, profile_picture, 'customer']
    );

    //Fetch inserted user using user_id
    const [userRows] = await pool.query('SELECT * FROM users WHERE user_id = ?', [result.insertId]);
    const user = userRows[0];
    delete user.password;

    //Set session for new user
    req.session.user = {
      id: user.user_id,
      username: user.name,
      email: user.email,
      role: user.role,
    };

    res.json({ message: 'Signup successful', user: req.session.user });
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
