import mysql from 'mysql2/promise';

let pool;

export async function getPool() {
  if (!pool) {
    pool = mysql.createPool({
      host: 'localhost',
      user: 'masteryazan',
      password: '0522337055', 
      database: 'autoeliteplus',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    console.log("Connected to MySQL autoeliteplus database");
  }
  return pool;
}
