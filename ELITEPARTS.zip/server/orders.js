import express from "express";
import { getPool } from "./db.js";

const router = express.Router();

//Create a new order after PayPal checkout
router.post("/", async (req, res) => {
  const { cart, paypal_id, total_price } = req.body;
  const sessionUser = req.session?.user;
  let user_id = sessionUser?.user_id;

  if (!user_id && req.body.user_id) {
    user_id = req.body.user_id;
    console.warn("Fallback to req.body.user_id:", user_id);
  }

  if (!user_id) {
    return res.status(401).json({ error: "Unauthorized: Login required" });
  }

  const pool = await getPool();
  const conn = await pool.getConnection();

  try {
    const [orderResult] = await conn.query(
      `INSERT INTO orders (user_id, total_price, paypal_id, status, order_date)
       VALUES (?, ?, ?, 'Paid', NOW())`,
      [user_id, total_price, paypal_id]
    );
    const order_id = orderResult.insertId;

    for (const item of cart) {
      await conn.query(
        `INSERT INTO orders_products (order_id, product_id, quantity)
         VALUES (?, ?, ?)`,
        [order_id, item.id, item.quantity]
      );
    }

    res.status(201).json({ success: true, order_id });
  } catch (err) {
    console.error("Order insert error:", err);
    res.status(500).json({ error: "Internal Server Error", details: err.message });
  } finally {
    conn.release();
  }
});

//Get all orders for the logged-in customer
router.get("/", async (req, res) => {
  const user = req.session?.user;
  if (!user) return res.status(401).json({ error: "Unauthorized" });

  const pool = await getPool();
  const conn = await pool.getConnection();

  try {
    const [orders] = await conn.query(
      `SELECT order_id, total_price, status, order_date
       FROM orders
       WHERE user_id = ?
       ORDER BY order_date DESC`,
      [user.user_id]
    );

    const ordersWithItems = [];

    for (const order of orders) {
      const [items] = await conn.query(
        `SELECT p.name, p.price, p.image, op.quantity
         FROM orders_products op
         JOIN products p ON op.product_id = p.product_id
         WHERE op.order_id = ?`,
        [order.order_id]
      );

      ordersWithItems.push({ ...order, items });
    }

    res.json(ordersWithItems);
  } catch (err) {
    console.error("Fetch customer orders error:", err);
    res.status(500).json({ error: "Failed to fetch orders" });
  } finally {
    conn.release();
  }
});

//Admin: Get ALL orders from ALL users with profile images
router.get("/all", async (req, res) => {
  const user = req.session?.user;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Admin access only" });
  }

  const pool = await getPool();
  const conn = await pool.getConnection();

  try {
   const [orders] = await conn.query(
  `SELECT o.order_id, o.total_price, o.status, o.order_date,
          u.name, u.profile_picture
   FROM orders o
   JOIN users u ON o.user_id = u.user_id
   ORDER BY o.order_date DESC`
);

    const ordersWithItems = [];

    for (const order of orders) {
      const [items] = await conn.query(
        `SELECT p.name, p.image, p.price, op.quantity
         FROM orders_products op
         JOIN products p ON op.product_id = p.product_id
         WHERE op.order_id = ?`,
        [order.order_id]
      );

      ordersWithItems.push({
        ...order,
        items,
      });
    }

    res.json(ordersWithItems);
  } catch (err) {
    console.error("Fetch all orders error:", err);
    res.status(500).json({ error: "Failed to fetch all orders" });
  } finally {
    conn.release();
  }
});

export default router;
