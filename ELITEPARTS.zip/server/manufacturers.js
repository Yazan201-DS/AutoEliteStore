import express from "express";
import { getPool } from "./db.js";

const router = express.Router();

//Get manufacturer by name (case-insensitive)
router.get("/name/:name", async (req, res) => {
  const nameParam = req.params.name.toLowerCase();

  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      "SELECT * FROM manufacturers WHERE LOWER(name) = ?",
      [nameParam]
    );

    if (rows.length > 0) {
      res.json(rows[0]);
    } else {
      res.status(404).json({ message: "Manufacturer not found" });
    }
  } catch (err) {
    console.error("Error fetching manufacturer:", err);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/products/:name", async (req, res) => {
  const nameParam = req.params.name.toLowerCase();

  try {
    const pool = await getPool();
    const [rows] = await pool.query(
      `SELECT 
         p.product_id,
         p.name,
         p.description,
         p.price,
         p.image,
         p.model_year,
         p.model_class,
         p.stock_quantity,
         m.name AS manufacturer_name,
         s.supplier_name,
         c.name AS category_name,
         sc.name AS subcategory_name
       FROM products p
       JOIN manufacturers m ON p.manufacturer_id = m.manufacturer_id
       JOIN suppliers s ON p.supplier_id = s.supplier_id
       LEFT JOIN categories c ON p.category_id = c.category_id
       LEFT JOIN subcategories sc ON p.subcategory_id = sc.subcategory_id
       WHERE LOWER(m.name) = ?`,
      [nameParam]
    );

    res.json(rows);
  } catch (err) {
    console.error("Error fetching products:", err);
    res.status(500).json({ message: "Server error" });
  }
});


export default router;
